package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
  @GetMapping("/")
    public String home() {
        return "<h1>Parabéns!</h1><p>Seu servidor Spring Boot está funcionando e pronto para o PostgreSQL.</p>";
    }
}
