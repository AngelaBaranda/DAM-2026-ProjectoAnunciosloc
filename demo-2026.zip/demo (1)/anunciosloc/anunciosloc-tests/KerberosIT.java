package pt.uan.anunciosloc.tests;

import org.junit.jupiter.api.*;
import javax.crypto.SecretKey;
import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class KerberosIT {

    private static String ticket;
    private static SecretKey chaveSessao;
    private static AnunciosLocClient clienteSeguro;

    @Test
    @Order(1)
    @DisplayName("Obter ticket do servidor Kerberos")
    void testObterTicket() throws Exception {
        KerberosClient kerberos = new KerberosClient();

        // Pede sessão ao servidor Kerberos
        String[] resposta = kerberos.pedirSessao("alice@uan.ao", System.currentTimeMillis());

        assertNotNull(resposta, "Resposta não deveria ser null");
        assertEquals(2, resposta.length, "Deveria receber [chaveSessao, ticket]");
        assertFalse(resposta[0].startsWith("ERRO"), "Não deveria dar erro: " + resposta[0]);

        // Decifra a chave de sessão com a chave de alice
        SecretKey chaveAlice = CryptoHelper.derivarChave("senha123");
        String chaveSessaoStr = CryptoHelper.decifrar(resposta[0], chaveAlice);
        chaveSessao = CryptoHelper.stringParaChave(chaveSessaoStr);
        ticket = resposta[1];

        assertNotNull(chaveSessao, "Chave de sessão não deveria ser null");
        assertNotNull(ticket, "Ticket não deveria ser null");
        System.out.println("Ticket obtido com sucesso!");
    }

    @Test
    @Order(2)
    @DisplayName("Invocar AnunciosLoc com ticket válido")
    void testInvocarComTicket() throws Exception {
        assertNotNull(ticket, "Precisa do ticket do teste anterior");

        // Cria cliente com handler de segurança
        clienteSeguro = new AnunciosLocClient(ticket, chaveSessao);
        String resultado = clienteSeguro.ping();

        assertNotNull(resultado, "Ping não deveria ser null");
        assertFalse(resultado.isEmpty(), "Ping deveria retornar info do servidor");
        System.out.println("Ping autenticado: " + resultado);
    }

    @Test
    @Order(3)
    @DisplayName("Activar utilizador com sessão autenticada")
    void testAtivarComSessao() throws Exception {
        assertNotNull(clienteSeguro, "Cliente seguro não inicializado");

        String resultado = clienteSeguro.ativarUtilizador("alice@uan.ao");
        assertTrue(resultado.startsWith("OK"),
            "Deveria activar com sucesso: " + resultado);
    }

    @Test
    @Order(4)
    @DisplayName("Pedido sem ticket deve ser rejeitado")
    void testSemTicketRejeitado() {
        assertThrows(Exception.class, () -> {
            // Cliente sem handler de segurança
            AnunciosLocClient clienteSemSeguranca = new AnunciosLocClient();
            clienteSemSeguranca.consultarSaldo("alice@uan.ao");
        }, "Deveria rejeitar pedido sem ticket");
    }
}