package pt.uan.anunciosloc.tests;

import org.junit.jupiter.api.*;
import pt.uan.anunciosloc.client.AnunciosLocServiceClient;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class AnunciosLocIT {

    private static AnunciosLocServiceClient client;

    @BeforeAll
    static void setup() throws Exception {
        client = new AnunciosLocServiceClient();
        // Limpa o estado do servidor antes de todos os testes
        client.clear();
    }

    // -------------------------------------------------------
    // Testes: ativarUtilizador
    // -------------------------------------------------------

    @Test
    @Order(1)
    @DisplayName("Activar utilizador com email válido")
    void testAtivarUtilizadorValido() {
        String resultado = client.ativarUtilizador("alice@uan.ao");
        assertTrue(resultado.startsWith("OK"),
            "Deveria activar com sucesso mas obteve: " + resultado);
    }

    @Test
    @Order(2)
    @DisplayName("Activar utilizador duplicado deve dar erro")
    void testAtivarUtilizadorDuplicado() {
        client.ativarUtilizador("bob@uan.ao");
        String resultado = client.ativarUtilizador("bob@uan.ao");
        assertTrue(resultado.startsWith("ERRO"),
            "Deveria dar erro por duplicado mas obteve: " + resultado);
    }

    @Test
    @Order(3)
    @DisplayName("Activar utilizador com email inválido deve dar erro")
    void testAtivarUtilizadorEmailInvalido() {
        String resultado = client.ativarUtilizador("email-invalido");
        assertTrue(resultado.startsWith("ERRO"),
            "Deveria rejeitar email inválido mas obteve: " + resultado);
    }

    // -------------------------------------------------------
    // Testes: consultarSaldo
    // -------------------------------------------------------

    @Test
    @Order(4)
    @DisplayName("Saldo inicial deve ser 10 pontos")
    void testSaldoInicial() {
        client.ativarUtilizador("carlos@uan.ao");
        int saldo = client.consultarSaldo("carlos@uan.ao");
        assertEquals(10, saldo,
            "Saldo inicial deveria ser 10 mas foi: " + saldo);
    }

    @Test
    @Order(5)
    @DisplayName("Consultar saldo de utilizador inexistente deve retornar -1")
    void testSaldoUtilizadorInexistente() {
        int saldo = client.consultarSaldo("naoexiste@uan.ao");
        assertEquals(-1, saldo,
            "Utilizador inexistente deveria retornar -1 mas retornou: " + saldo);
    }

    // -------------------------------------------------------
    // Testes: postarMensagem
    // -------------------------------------------------------

    @Test
    @Order(6)
    @DisplayName("Postar anúncio com utilizador válido")
    void testPostarMensagemValida() {
        client.ativarUtilizador("diana@uan.ao");
        String resultado = client.postarMensagem(
            "diana@uan.ao",
            "Largo da Independência",
            "Arrendo vivenda na Maianga"
        );
        assertTrue(resultado.startsWith("OK"),
            "Deveria postar com sucesso mas obteve: " + resultado);
    }

    @Test
    @Order(7)
    @DisplayName("Postar anúncio com utilizador inexistente deve dar erro")
    void testPostarMensagemUtilizadorInexistente() {
        String resultado = client.postarMensagem(
            "fantasma@uan.ao",
            "Belas Shopping",
            "Vendo carro"
        );
        assertTrue(resultado.startsWith("ERRO"),
            "Deveria dar erro mas obteve: " + resultado);
    }

    // -------------------------------------------------------
    // Testes: receberMensagem
    // -------------------------------------------------------

    @Test
    @Order(8)
    @DisplayName("Receber mensagens de um local com anúncios")
    void testReceberMensagemComAnuncios() {
        // Garante que há um anúncio no local
        client.ativarUtilizador("eve@uan.ao");
        client.postarMensagem("eve@uan.ao", "Belas Shopping", "Procuro sócio para negócio");

        // Outro utilizador recebe o anúncio
        client.ativarUtilizador("frank@uan.ao");
        String resultado = client.receberMensagem("frank@uan.ao", "Belas Shopping");

        assertFalse(resultado.startsWith("ERRO"),
            "Não deveria dar erro mas obteve: " + resultado);
        assertTrue(resultado.contains("Belas Shopping"),
            "Resposta deveria mencionar o local: " + resultado);
    }

    @Test
    @Order(9)
    @DisplayName("Autor recebe bónus após entrega do anúncio")
    void testBonusAposEntrega() {
        // Cria autor e posta anúncio
        client.ativarUtilizador("grace@uan.ao");
        client.postarMensagem("grace@uan.ao", "Ginásio do Camama", "Aulas de karaté");

        int saldoAntes = client.consultarSaldo("grace@uan.ao");

        // Outro utilizador recebe o anúncio
        client.ativarUtilizador("henry@uan.ao");
        client.receberMensagem("henry@uan.ao", "Ginásio do Camama");

        int saldoDepois = client.consultarSaldo("grace@uan.ao");

        assertTrue(saldoDepois > saldoAntes,
            "Saldo do autor deveria aumentar após entrega. Antes: "
            + saldoAntes + " Depois: " + saldoDepois);
    }

    @Test
    @Order(10)
    @DisplayName("Receber mensagens de local sem anúncios")
    void testReceberMensagemLocalVazio() {
        client.ativarUtilizador("ivan@uan.ao");
        String resultado = client.receberMensagem("ivan@uan.ao", "Local Inexistente");
        assertFalse(resultado.startsWith("ERRO"),
            "Não deveria dar erro, apenas informar que está vazio: " + resultado);
    }

    // -------------------------------------------------------
    // Testes: ping
    // -------------------------------------------------------

    @Test
    @Order(11)
    @DisplayName("Ping deve retornar resposta não vazia")
    void testPing() {
        String resultado = client.ping();
        assertNotNull(resultado, "Ping não deveria retornar null");
        assertFalse(resultado.isEmpty(), "Ping não deveria retornar string vazia");
    }
}