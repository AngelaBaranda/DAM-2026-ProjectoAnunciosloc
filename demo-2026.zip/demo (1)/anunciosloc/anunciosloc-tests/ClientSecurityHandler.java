package pt.uan.anunciosloc.tests;

import jakarta.xml.ws.handler.MessageContext;
import jakarta.xml.ws.handler.soap.*;
import javax.crypto.SecretKey;
import javax.xml.namespace.QName;
import java.util.*;

public class ClientSecurityHandler implements SOAPHandler<SOAPMessageContext> {

    private String ticket;
    private SecretKey chaveSessao;

    public ClientSecurityHandler(String ticket, SecretKey chaveSessao) {
        this.ticket     = ticket;
        this.chaveSessao = chaveSessao;
    }

    @Override
    public boolean handleMessage(SOAPMessageContext ctx) {
        boolean isOutbound = (Boolean) ctx.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);

        if (isOutbound) {
            try {
                // Adiciona ticket e autenticador no cabeçalho SOAP
                var message  = ctx.getMessage();
                var envelope = message.getSOAPPart().getEnvelope();
                var header   = envelope.getHeader() != null
                             ? envelope.getHeader()
                             : envelope.addHeader();

                // Ticket
                var ticketEl = header.addHeaderElement(
                    new QName("http://security.anunciosloc.uan.pt/", "ticket", "sec")
                );
                ticketEl.setTextContent(ticket);

                // Autenticador: timestamp cifrado com chave de sessão
                long timestamp = System.currentTimeMillis();
                String autenticador = CryptoHelper.cifrar(
                    String.valueOf(timestamp), chaveSessao
                );
                var authEl = header.addHeaderElement(
                    new QName("http://security.anunciosloc.uan.pt/", "autenticador", "sec")
                );
                authEl.setTextContent(autenticador);

                // MAC do corpo da mensagem
                String corpo = envelope.getBody().getTextContent();
                String mac = CryptoHelper.gerarMAC(corpo + timestamp, chaveSessao);
                var macEl = header.addHeaderElement(
                    new QName("http://security.anunciosloc.uan.pt/", "mac", "sec")
                );
                macEl.setTextContent(mac);

            } catch (Exception e) {
                System.err.println("Erro no handler cliente: " + e.getMessage());
            }
        }
        return true;
    }

    @Override
    public boolean handleFault(SOAPMessageContext ctx) { return true; }

    @Override
    public void close(MessageContext ctx) {}

    @Override
    public Set<QName> getHeaders() { return new HashSet<>(); }
}