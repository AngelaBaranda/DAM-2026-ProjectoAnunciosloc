package pt.uan.anunciosloc.kerberos;

import com.sun.net.httpserver.HttpContext;
import com.sun.net.httpserver.HttpServer;
import java.net.Inet4Address;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.util.Collections;
import javax.xml.ws.Endpoint;

public class KerberosServer {

    public static void main(String[] args) throws Exception {
        int port = args.length > 0 ? Integer.parseInt(args[0]) : 8085;
        String path = "/kerberos";

        KerberosEndpoint service = new KerberosEndpoint();
        Endpoint endpoint = Endpoint.create(service);
        // Liga em 0.0.0.0 (todas as interfaces) — telemóvel na mesma Wi‑Fi consegue aceder
        HttpServer httpServer = HttpServer.create(new InetSocketAddress(port), 0);
        HttpContext context = httpServer.createContext(path);
        endpoint.publish(context);
        httpServer.start();

        String lan = detectLanUrl(port, path);
        System.out.println("==================================================");
        System.out.println("Servidor Kerberos ACTIVO na porta " + port);
        System.out.println("PC:  http://127.0.0.1:" + port + path);
        if (lan != null) {
            System.out.println("Te móvel (mesma Wi-Fi): " + lan);
            System.out.println("Emulador Android:       http://10.0.2.2:" + port + path);
        }
        System.out.println("WSDL: http://127.0.0.1:" + port + path + "?wsdl");
        System.out.println("==================================================");

        if (System.console() != null) {
            System.out.println("Prima ENTER para terminar...");
            System.in.read();
        } else {
            Thread.currentThread().join();
        }
        endpoint.stop();
        httpServer.stop(0);
    }

    private static String detectLanUrl(int port, String path) {
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) {
                    continue;
                }
                for (var addr : Collections.list(ni.getInetAddresses())) {
                    if (addr instanceof Inet4Address && !addr.isLoopbackAddress()) {
                        return "http://" + addr.getHostAddress() + ":" + port + path;
                    }
                }
            }
        } catch (Exception ignored) {
            // ignora
        }
        return null;
    }
}
