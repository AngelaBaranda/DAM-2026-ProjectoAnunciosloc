package pt.uan.anunciosloc.kerberos;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.crypto.SecretKey;
import java.util.HashMap;
import java.util.Map;

@WebService(
    name = "KerberosAS",
    targetNamespace = "http://kerberos.anunciosloc.uan.pt/"
)
public class KerberosEndpoint {

    // Utilizadores pré-registados: email -> senha
    private Map<String, String> utilizadores = new HashMap<>();

    // Chave secreta do servidor AnunciosLoc (pré-partilhada)
    private static final String SENHA_ANUNCIOSLOC = "anunciosloc-secret-2025";

    public KerberosEndpoint() {
        // Utilizadores pré-registados conforme o enunciado
        utilizadores.put("alice@uan.ao",   "senha123");
        utilizadores.put("bob@uan.ao",     "senha456");
        utilizadores.put("carlos@uan.ao",  "senha789");
        utilizadores.put("diana@uan.ao",   "senha321");
    }

    /**
     * Login com email + senha (muitas apps Android chamam {@code login} em vez de {@code pedirSessao}).
     * Valida a senha no servidor e devolve o mesmo que {@link #pedirSessao}.
     */
    @WebMethod
    public String[] login(String email, String senha, long timestamp) {
        String emailKey = email == null ? "" : email.trim().toLowerCase();
        if (!utilizadores.containsKey(emailKey)) {
            return new String[]{"ERRO: utilizador desconhecido — regista primeiro (registarUtilizador)"};
        }
        String pwd = utilizadores.get(emailKey);
        if (senha == null || !pwd.equals(senha)) {
            return new String[]{"ERRO: senha inválida"};
        }
        return pedirSessao(email, timestamp);
    }

    // Operação principal: o cliente pede uma nova sessão (senha validada no cliente via cifra)
    // Devolve [chaveSessaoCifrada, ticketCifrado]
    @WebMethod
    public String[] pedirSessao(String email, long timestamp) {
        try {
            // 1. Verifica se o utilizador existe
            String emailKey = email == null ? "" : email.trim().toLowerCase();
            if (!utilizadores.containsKey(emailKey)) {
                return new String[]{"ERRO: utilizador desconhecido — regista primeiro no Kerberos (registarUtilizador)"};
            }

            // 2. Verifica frescura do timestamp (max 5 minutos)
            long agora = System.currentTimeMillis();
            if (Math.abs(agora - timestamp) > 5 * 60 * 1000) {
                return new String[]{"ERRO: timestamp expirado"};
            }

            // 3. Gera chave de sessão aleatória
            SecretKey chaveSessao = CryptoHelper.gerarChaveSessao();
            String chaveSessaoStr = CryptoHelper.chaveParaString(chaveSessao);

            // 4. Cria o ticket: {email, chaveSessao, timestamp}
            String conteudoTicket = emailKey + "|" + chaveSessaoStr + "|" + timestamp;

            // 5. Cifra o ticket com a chave do AnunciosLoc
            SecretKey chaveAnunciosLoc = CryptoHelper.derivarChave(SENHA_ANUNCIOSLOC);
            String ticketCifrado = CryptoHelper.cifrar(conteudoTicket, chaveAnunciosLoc);

            // 6. Cifra a chave de sessão com a chave do utilizador
            String senha = utilizadores.get(emailKey);
            SecretKey chaveUtilizador = CryptoHelper.derivarChave(senha);
            String chaveSessaoCifrada = CryptoHelper.cifrar(chaveSessaoStr, chaveUtilizador);

            System.out.println("Sessão emitida para: " + emailKey);
            return new String[]{chaveSessaoCifrada, ticketCifrado};

        } catch (Exception e) {
            return new String[]{"ERRO: " + e.getMessage()};
        }
    }

    /**
     * Regista utilizador para o cliente mobile poder usar {@link #pedirSessao}.
     * A senha deve ser a mesma usada no registo/login do AnunciosLoc (mín. 6 caracteres).
     */
    @WebMethod
    public synchronized String registarUtilizador(String email, String senha) {
        if (email == null || !email.matches("[a-zA-Z0-9.]+@[a-zA-Z0-9.]+")) {
            return "ERRO: email inválido";
        }
        if (senha == null || senha.length() < 6) {
            return "ERRO: senha deve ter pelo menos 6 caracteres";
        }
        utilizadores.put(email.trim().toLowerCase(), senha);
        return "OK: utilizador registado no Kerberos — " + email;
    }

    @WebMethod
    public String ping() {
        return "Servidor Kerberos activo. Utilizadores registados: " + utilizadores.size();
    }
}
