package pt.uan.anunciosloc.kerberos;

import javax.crypto.*;
import javax.crypto.spec.*;
import java.security.*;
import java.util.Base64;

public class CryptoHelper {

    private static final String ALGO = "AES";
    private static final int ITERATIONS = 1000; // constante c do enunciado

    // Deriva a chave secreta do utilizador a partir da senha
    // Implementa hash(senha(u), c) como descrito no enunciado
    public static SecretKey derivarChave(String senha) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = senha.getBytes();

        // Aplica o hash c vezes (iterações)
        for (int i = 0; i < ITERATIONS; i++) {
            hash = digest.digest(hash);
        }

        // Usa os primeiros 16 bytes como chave AES-128
        byte[] chave16 = new byte[16];
        System.arraycopy(hash, 0, chave16, 0, 16);
        return new SecretKeySpec(chave16, ALGO);
    }

    // Cifra dados com uma chave secreta
    public static String cifrar(String dados, SecretKey chave) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, chave);
        byte[] cifrado = cipher.doFinal(dados.getBytes());
        return Base64.getEncoder().encodeToString(cifrado);
    }

    // Decifra dados com uma chave secreta
    public static String decifrar(String dadosCifrados, SecretKey chave) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE, chave);
        byte[] decifrado = cipher.doFinal(Base64.getDecoder().decode(dadosCifrados));
        return new String(decifrado);
    }

    // Gera um MAC para garantir integridade do pedido
    public static String gerarMAC(String dados, SecretKey chave) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(chave);
        byte[] macBytes = mac.doFinal(dados.getBytes());
        return Base64.getEncoder().encodeToString(macBytes);
    }

    // Verifica se o MAC é válido
    public static boolean verificarMAC(String dados, String mac, SecretKey chave) throws Exception {
        String macEsperado = gerarMAC(dados, chave);
        return macEsperado.equals(mac);
    }

    // Gera uma chave de sessão aleatória
    public static SecretKey gerarChaveSessao() throws Exception {
        KeyGenerator kg = KeyGenerator.getInstance(ALGO);
        kg.init(128);
        return kg.generateKey();
    }

    // Converte SecretKey para String (para transmissão)
    public static String chaveParaString(SecretKey chave) {
        return Base64.getEncoder().encodeToString(chave.getEncoded());
    }

    // Converte String de volta para SecretKey
    public static SecretKey stringParaChave(String str) {
        byte[] bytes = Base64.getDecoder().decode(str);
        return new SecretKeySpec(bytes, ALGO);
    }
}
