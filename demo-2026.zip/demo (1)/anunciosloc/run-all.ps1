param(
    [switch]$StartJuddi = $false,
    [switch]$StartTomcat = $false,
    [string]$TomcatPath = "C:\tomcat9"
)

$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$runtimeDir = Join-Path $root ".runtime"
$logsDir = Join-Path $runtimeDir "logs"
$pidsFile = Join-Path $runtimeDir "pids.txt"

if (!(Test-Path $runtimeDir)) { New-Item -ItemType Directory -Path $runtimeDir | Out-Null }
if (!(Test-Path $logsDir)) { New-Item -ItemType Directory -Path $logsDir | Out-Null }

if (Test-Path $pidsFile) {
    Write-Host "Ja existe um arranque anterior em .runtime/pids.txt."
    Write-Host "Se necessario, executa primeiro: .\stop-all.ps1"
}

Write-Host "A compilar modulos Maven (skip tests)..."
Push-Location $root
try {
    & mvn -DskipTests install
}
finally {
    Pop-Location
}

function Start-ServiceProcess {
    param(
        [string]$Name,
        [string]$WorkingDir,
        [string]$Command
    )

    $stdout = Join-Path $logsDir "$Name.out.log"
    $stderr = Join-Path $logsDir "$Name.err.log"

    $proc = Start-Process `
        -FilePath "powershell.exe" `
        -ArgumentList "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", "Set-Location '$WorkingDir'; $Command" `
        -PassThru `
        -RedirectStandardOutput $stdout `
        -RedirectStandardError $stderr

    "$($proc.Id)|$Name|$WorkingDir|$Command" | Add-Content $pidsFile
    Write-Host ("[{0}] iniciado (PID={1})" -f $Name, $proc.Id)
}

if (Test-Path $pidsFile) {
    Remove-Item $pidsFile -Force
}

if ($StartTomcat) {
    $startup = Join-Path $TomcatPath "bin\startup.bat"
    if (Test-Path $startup) {
        Write-Host "A arrancar Tomcat..."
        Start-Process -FilePath $startup | Out-Null
        Write-Host "Tomcat iniciado."
    } else {
        Write-Warning "Tomcat nao encontrado em '$startup'."
    }
}

if ($StartJuddi) {
    $dockerCmd = Get-Command docker -ErrorAction SilentlyContinue
    if (-not $dockerCmd) {
        Write-Warning "Docker nao encontrado no PATH. jUDDI nao foi iniciado."
        Write-Host "Instala o Docker Desktop ou arranca jUDDI por Tomcat."
    } else {
        Write-Host "A arrancar jUDDI por Docker Compose..."
        Push-Location $root
        try {
            & docker compose up -d
        }
        finally {
            Pop-Location
        }
    }
}

Start-ServiceProcess -Name "infrastructure-ws" -WorkingDir (Join-Path $root "infrastructure-ws") -Command "mvn exec:java"
Start-ServiceProcess -Name "anunciosloc-ws" -WorkingDir (Join-Path $root "anunciosloc-ws") -Command "mvn exec:java"
Start-ServiceProcess -Name "kerberos-ws" -WorkingDir (Join-Path $root "kerberos-ws") -Command "mvn exec:java `"-Dexec.args=8085`""
Start-ServiceProcess -Name "anunciosloc-web" -WorkingDir (Join-Path $root "anunciosloc-web") -Command "python -m http.server 5500"

Write-Host ""
Write-Host "Tudo iniciado."
Write-Host "Frontend: http://localhost:5500"
Write-Host "Logs: .runtime/logs"
Write-Host "Para parar tudo: .\stop-all.ps1"
