package pt.uan.anunciosloc.infrastructure;

import org.apache.juddi.v3.client.config.UDDIClient;
import org.apache.juddi.v3.client.transport.Transport;
import org.uddi.api_v3.*;
import org.uddi.v3_service.UDDIInquiryPortType;
import org.uddi.v3_service.UDDIPublicationPortType;
import org.uddi.v3_service.UDDISecurityPortType;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.NetworkInterface;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class UDDIHelper {

    private static final String UDDI_URL = "http://localhost:9090/juddiv3";
    /** Negócio UDDI pai dos serviços (obrigatório no UDDI v3). */
    private static final String BUSINESS_ROOT_NAME = "pt.uan.anunciosloc";
    private static final Path LOCAL_REGISTRY_FILE =
        Paths.get(System.getProperty("user.home"), ".anunciosloc-uddi-registry.properties");

    private static final Pattern PORT_IN_URL = Pattern.compile(":(\\d{4,5})/");

    /**
     * Registo a partir da app mobile (nome + GPS). jUDDI é opcional — usa sempre registo local.
     * URL inclui lat/lon para aparecer na listagem mesmo sem infrastructure-ws a correr nessa porta.
     */
    public static String registarInfraestruturaCatalog(String nome, double lat, double lon) {
        if (nome == null || nome.isBlank()) {
            return "ERRO: indica o nome da infraestrutura";
        }
        String safe = nome.trim().replace(" ", "_").replaceAll("[^a-zA-Z0-9_áàâãéêíóôõúçÁÀÂÃÉÊÍÓÔÕÚÇ]", "");
        if (safe.isBlank()) {
            safe = "Infra";
        }
        String serviceName = "D01_Infrastructure_" + safe;
        int port = proximaPortaLivre();
        String lan = detectLanUrl(port, "/infrastructure");
        String base = lan != null ? lan : ("http://127.0.0.1:" + port + "/infrastructure");
        try {
            String encNome = URLEncoder.encode(nome.trim(), StandardCharsets.UTF_8);
            String url = base + "?lat=" + lat + "&lon=" + lon + "&nome=" + encNome + "&radius=100";
            registar(serviceName, url);
            return "OK: infraestrutura '" + nome.trim() + "' registada (porta " + port + "). "
                + "jUDDI opcional — registo local: " + LOCAL_REGISTRY_FILE;
        } catch (Exception e) {
            return "ERRO: " + e.getMessage();
        }
    }

    private static int proximaPortaLivre() {
        LinkedHashSet<Integer> usadas = new LinkedHashSet<>();
        try {
            Properties p = loadLocalRegistry();
            for (String key : p.stringPropertyNames()) {
                String url = p.getProperty(key);
                if (url == null) {
                    continue;
                }
                Matcher m = PORT_IN_URL.matcher(url);
                if (m.find()) {
                    usadas.add(Integer.parseInt(m.group(1)));
                }
            }
        } catch (IOException ignored) {
            // ignora
        }
        for (int port = 8081; port <= 8099; port++) {
            if (!usadas.contains(port)) {
                return port;
            }
        }
        return 8099;
    }

    static String detectLanUrl(int port, String path) {
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) {
                    continue;
                }
                for (var addr : Collections.list(ni.getInetAddresses())) {
                    if (addr instanceof Inet4Address && !addr.isLoopbackAddress()) {
                        return "http://" + addr.getHostAddress() + ":" + port + path;
                    }
                }
            }
        } catch (Exception ignored) {
            // ignora
        }
        return null;
    }

    // Regista o serviço no UDDI
    public static void registar(String serviceName, String serviceUrl) {
        try {
            UDDIClient client = new UDDIClient();
            client.start();

            Transport transport = client.getTransport("default");
            UDDISecurityPortType security = transport.getUDDISecurityService(UDDI_URL + "/services/security");
            UDDIPublicationPortType publication = transport.getUDDIPublishService(UDDI_URL + "/services/publish");
            UDDIInquiryPortType inquiry = transport.getUDDIInquiryService(UDDI_URL + "/services/inquiry");

            // Autenticar no UDDI (utilizador padrão do jUDDI)
            GetAuthToken getAuthToken = new GetAuthToken();
            getAuthToken.setUserID("uddiadmin");
            getAuthToken.setCred("da_password1");
            AuthToken authToken = security.getAuthToken(getAuthToken);
            String token = authToken.getAuthInfo();

            String businessKey = obterOuCriarNegocio(inquiry, publication, token);

            // Criar o serviço a registar
            SaveService saveService = new SaveService();
            saveService.setAuthInfo(token);

            BusinessService service = new BusinessService();
            service.setBusinessKey(businessKey);

            // Nome do serviço
            Name name = new Name();
            name.setValue(serviceName);
            service.getName().add(name);

            // URL do serviço (access point)
            BindingTemplates bindingTemplates = new BindingTemplates();
            BindingTemplate bindingTemplate = new BindingTemplate();
            AccessPoint accessPoint = new AccessPoint();
            accessPoint.setValue(serviceUrl);
            accessPoint.setUseType("endPoint");
            bindingTemplate.setAccessPoint(accessPoint);
            bindingTemplates.getBindingTemplate().add(bindingTemplate);
            service.setBindingTemplates(bindingTemplates);

            saveService.getBusinessService().add(service);
            publication.saveService(saveService);

            System.out.println("Serviço '" + serviceName + "' registado no UDDI com sucesso!");
            client.stop();

            // Espelho no ficheiro local para o anunciosloc-ws descobrir sempre todas as infra
            // (a pesquisa UDDI por vezes não devolve tudo; antes só se lia o local se UDDI viesse vazio).
            registarLocal(serviceName, serviceUrl);

        } catch (Exception e) {
            System.err.println("UDDI indisponível (" + e.getMessage() + "). A usar registo local.");
            registarLocal(serviceName, serviceUrl);
        }
    }

    private static String obterOuCriarNegocio(
            UDDIInquiryPortType inquiry,
            UDDIPublicationPortType publication,
            String token) throws Exception {

        FindBusiness findBusiness = new FindBusiness();
        findBusiness.setAuthInfo(token);
        Name search = new Name();
        search.setValue(BUSINESS_ROOT_NAME);
        findBusiness.getName().add(search);

        BusinessList list = inquiry.findBusiness(findBusiness);
        if (list.getBusinessInfos() != null) {
            List<BusinessInfo> infos = list.getBusinessInfos().getBusinessInfo();
            if (infos != null && !infos.isEmpty()) {
                return infos.get(0).getBusinessKey();
            }
        }

        SaveBusiness saveBusiness = new SaveBusiness();
        saveBusiness.setAuthInfo(token);
        BusinessEntity entity = new BusinessEntity();
        Name bn = new Name();
        bn.setValue(BUSINESS_ROOT_NAME);
        entity.getName().add(bn);
        saveBusiness.getBusinessEntity().add(entity);

        BusinessDetail detail = publication.saveBusiness(saveBusiness);
        return detail.getBusinessEntity().get(0).getBusinessKey();
    }

    // Pesquisa serviços no UDDI pelo nome
    public static List<String> pesquisar(String nomeServico) {
        List<String> urls = new ArrayList<>();
        try {
            UDDIClient client = new UDDIClient();
            client.start();

            Transport transport = client.getTransport("default");
            org.uddi.v3_service.UDDIInquiryPortType inquiry =
                    transport.getUDDIInquiryService(UDDI_URL + "/services/inquiry");

            FindService findService = new FindService();
            Name name = new Name();
            name.setValue("%" + nomeServico + "%"); // pesquisa por padrão
            findService.getName().add(name);

            ServiceList serviceList = inquiry.findService(findService);

            if (serviceList.getServiceInfos() != null) {
                for (ServiceInfo info : serviceList.getServiceInfos().getServiceInfo()) {
                    // Obtém os detalhes do serviço para extrair a URL
                    GetServiceDetail detail = new GetServiceDetail();
                    detail.getServiceKey().add(info.getServiceKey());
                    ServiceDetail serviceDetail = inquiry.getServiceDetail(detail);

                    for (BusinessService bs : serviceDetail.getBusinessService()) {
                        if (bs.getBindingTemplates() != null) {
                            for (BindingTemplate bt : bs.getBindingTemplates().getBindingTemplate()) {
                                if (bt.getAccessPoint() != null) {
                                    urls.add(bt.getAccessPoint().getValue());
                                }
                            }
                        }
                    }
                }
            }
            client.stop();
        } catch (Exception e) {
            System.err.println("UDDI indisponível para pesquisa (" + e.getMessage() + "). A usar registo local.");
        }
        // Funde UDDI + registo local (dedupe). Antes só se lia o local quando UDDI devolvia lista vazia,
        // e o registo local não era actualizado quando o UDDI publicava com sucesso — novas infra não apareciam.
        LinkedHashSet<String> merged = new LinkedHashSet<>(urls);
        merged.addAll(pesquisarLocal(nomeServico));
        return new ArrayList<>(merged);
    }

    private static synchronized void registarLocal(String serviceName, String serviceUrl) {
        try {
            Properties p = loadLocalRegistry();
            p.setProperty(serviceName, serviceUrl);
            saveLocalRegistry(p);
            System.out.println("Serviço '" + serviceName + "' registado no registo local: " + serviceUrl);
        } catch (IOException io) {
            System.err.println("Falha ao gravar registo local UDDI: " + io.getMessage());
        }
    }

    private static synchronized List<String> pesquisarLocal(String nomeServico) {
        try {
            Properties p = loadLocalRegistry();
            String needle = nomeServico == null ? "" : nomeServico.toLowerCase();
            return p.stringPropertyNames().stream()
                .filter(k -> k.toLowerCase().contains(needle))
                .map(p::getProperty)
                .filter(v -> v != null && !v.isBlank())
                .distinct()
                .collect(Collectors.toList());
        } catch (IOException io) {
            System.err.println("Falha ao ler registo local UDDI: " + io.getMessage());
            return new ArrayList<>();
        }
    }

    private static Properties loadLocalRegistry() throws IOException {
        Properties p = new Properties();
        if (!Files.exists(LOCAL_REGISTRY_FILE)) {
            return p;
        }
        try (InputStream in = Files.newInputStream(LOCAL_REGISTRY_FILE)) {
            p.load(in);
        }
        return p;
    }

    private static void saveLocalRegistry(Properties p) throws IOException {
        Path parent = LOCAL_REGISTRY_FILE.getParent();
        if (parent != null && !Files.exists(parent)) {
            Files.createDirectories(parent);
        }
        try (OutputStream out = Files.newOutputStream(LOCAL_REGISTRY_FILE)) {
            p.store(out, "AnunciosLoc local UDDI fallback registry");
        }
    }
}
