package pt.uan.anunciosloc.infrastructure;



import javax.jws.WebMethod;

import javax.jws.WebService;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



// web service endpoint

@WebService(

    name = "Infrastructure",

    targetNamespace = "http://infrastructure.anunciosloc.uan.pt/"

)

public class InfrastructureEndpoint {



    // Nome desta infraestrutura

    private String name;



    // Capacidade máxima de utilizadores

    private int capacity;



    // Coordenadas GPS: latitude, longitude, raio

    private double latitude;

    private double longitude;

    private int radius;



    // Saldos dos utilizadores nesta infraestrutura

    private Map<String, Integer> userBalances = new HashMap<>();



    // Anúncios armazenados nesta infraestrutura (réplica local)

    private final List<String> anunciosLocais = new ArrayList<>();

    // Estatísticas

    private int totalAds = 0;

    private int totalDeliveries = 0;



    // Número de sequência para controlo de versão (quorum)

    private int sequenceNumber = 0;



    public InfrastructureEndpoint(String name, double lat, double lon, int radius, int capacity) {

        this.name = name;

        this.latitude = lat;

        this.longitude = lon;

        this.radius = radius;

        this.capacity = capacity;

    }



    // Construtor sem argumentos (exigido pelo JAX-WS)

    public InfrastructureEndpoint() {

        this("Default", 0.0, 0.0, 10, 100);

    }



    @WebMethod

    public String obterInfoInfraestrutura() {

        return String.format(
            java.util.Locale.ROOT,
            "Nome: %s | GPS: [%.4f, %.4f, %dm] | Capacidade: %d | Anuncios: %d | Entregas: %d",
            name, latitude, longitude, radius, capacity, totalAds, totalDeliveries
        );

    }



    @WebMethod

    public String criarLocal(String localName, double lat, double lon, int r) {

        // Regista um local associado a esta infraestrutura

        return "Local criado: " + localName + " em [" + lat + ", " + lon + ", " + r + "m]";

    }



    @WebMethod

    public String definirRestricao(String regra) {

        // Define uma regra de filtragem de mensagens

        return "Restrição definida: " + regra;

    }



    @WebMethod

    public int obterSaldo(String email) {

        // Devolve o saldo do utilizador nesta infraestrutura

        return userBalances.getOrDefault(email, 0);

    }



    @WebMethod

    public void atualizarSaldo(String email, int novoSaldo) {

        userBalances.put(email, novoSaldo);

    }



    @WebMethod

    public String ping() {

        return "Infrastructure '" + name + "' está activa. Anuncios: " + totalAds;

    }



    /** Publica anúncio na réplica desta infraestrutura (chamado pelo servidor central). */

    @WebMethod

    public String postarAnuncio(String emailAutor, String texto) {

        if (texto == null || texto.isBlank()) {

            return "ERRO: texto vazio";

        }

        String linha = emailAutor + ": " + texto.trim();

        anunciosLocais.add(linha);

        totalAds++;

        return "OK: anúncio na infra '" + name + "' — total: " + totalAds;

    }



    @WebMethod

    public String listarAnunciosLocais() {

        if (anunciosLocais.isEmpty()) {

            return "Sem anúncios nesta infraestrutura.";

        }

        StringBuilder sb = new StringBuilder("Anúncios em '" + name + "':\n");

        for (String a : anunciosLocais) {

            sb.append("  - ").append(a).append("\n");

        }

        return sb.toString();

    }



    @WebMethod

    public void clear() {

        userBalances.clear();

        totalAds = 0;

        totalDeliveries = 0;

    }



    @WebMethod

    public int[] lerSaldo(String email) {

        // Devolve [saldo, sequenceNumber]

        // O sequenceNumber serve para o AnunciosLoc saber qual réplica tem o valor mais recente

        int saldo = userBalances.getOrDefault(email, 10);

        return new int[]{saldo, sequenceNumber};

    }



    @WebMethod

    public String escreverSaldo(String email, int novoSaldo, int seq) {

        // Só actualiza se o seq for mais recente que o actual

        if (seq >= this.sequenceNumber) {

            userBalances.put(email, novoSaldo);

            this.sequenceNumber = seq;

            return "OK";

        }

        return "IGNORADO: sequência desactualizada";

    }

}

