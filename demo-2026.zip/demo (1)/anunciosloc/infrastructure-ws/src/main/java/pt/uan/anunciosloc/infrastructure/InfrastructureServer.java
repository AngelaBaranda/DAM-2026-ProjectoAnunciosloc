package pt.uan.anunciosloc.infrastructure;

import com.sun.net.httpserver.HttpContext;
import com.sun.net.httpserver.HttpServer;
import java.net.Inet4Address;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.util.Collections;
import javax.xml.ws.Endpoint;

public class InfrastructureServer {

    public static void main(String[] args) throws Exception {

        String name     = args.length > 0 ? args[0] : "Largo da Independência";
        double lat      = args.length > 1 ? Double.parseDouble(args[1]) : -8.8147;
        double lon      = args.length > 2 ? Double.parseDouble(args[2]) : 13.2302;
        int    radius   = args.length > 3 ? Integer.parseInt(args[3])   : 20;
        int    capacity = args.length > 4 ? Integer.parseInt(args[4])   : 50;
        int    port     = args.length > 5 ? Integer.parseInt(args[5])   : 8081;

        String groupId      = "D01";
        String serviceName  = groupId + "_Infrastructure_" + name.replace(" ", "_");
        String path         = "/infrastructure";
        String serviceUrl   = "http://127.0.0.1:" + port + path;

        InfrastructureEndpoint service = new InfrastructureEndpoint(
            name, lat, lon, radius, capacity
        );
        Endpoint endpoint = Endpoint.create(service);
        HttpServer httpServer = HttpServer.create(new InetSocketAddress(port), 0);
        HttpContext context = httpServer.createContext(path);
        endpoint.publish(context);
        httpServer.start();

        System.out.println("Infraestrutura '" + name + "' activa em: " + serviceUrl);
        String lan = detectLanUrl(port, path);
        if (lan != null) {
            System.out.println("Te móvel (mesma Wi-Fi): " + lan);
            System.out.println("Emulador Android:       http://10.0.2.2:" + port + path);
        }

        UDDIHelper.registar(serviceName, lan != null ? lan : serviceUrl);

        if (System.console() != null) {
            System.out.println("Prima ENTER para terminar...");
            System.in.read();
        } else {
            Thread.currentThread().join();
        }
        endpoint.stop();
        httpServer.stop(0);
    }

    private static String detectLanUrl(int port, String path) {
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) {
                    continue;
                }
                for (var addr : Collections.list(ni.getInetAddresses())) {
                    if (addr instanceof Inet4Address && !addr.isLoopbackAddress()) {
                        return "http://" + addr.getHostAddress() + ":" + port + path;
                    }
                }
            }
        } catch (Exception ignored) {
            // ignora
        }
        return null;
    }
}
