-- PostgreSQL schema for AnunciosLoc (minimal JDBC persistence)
-- Nota: índices são criados em Java após migrações, para evitar falhas quando a tabela já existia com outro esquema.

CREATE TABLE IF NOT EXISTS utilizadores (
    email VARCHAR(320) PRIMARY KEY,
    saldo INTEGER NOT NULL,
    ultimo_anuncio_ms BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS anuncios (
    id UUID PRIMARY KEY,
    email_autor VARCHAR(320) NOT NULL REFERENCES utilizadores(email) ON DELETE CASCADE,
    local_name TEXT NOT NULL,
    texto TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS dashboard_metricas (
    chave VARCHAR(64) PRIMARY KEY,
    valor BIGINT NOT NULL DEFAULT 0
);

INSERT INTO dashboard_metricas (chave, valor) VALUES ('entregas', 0)
ON CONFLICT (chave) DO NOTHING;

-- Tabela entregas: criada/migrada em Java (AnunciosLocDb.migrateEntregasIfNeeded)
-- Tabela mensagens_chat: criada/migrada em Java (AnunciosLocDb.migrateChatIfNeeded)
