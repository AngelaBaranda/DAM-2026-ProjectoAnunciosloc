package pt.uan.anunciosloc;

import javax.xml.ws.Service;
import javax.xml.namespace.QName;
import java.net.URL;
import java.util.*;
import java.util.concurrent.*;

public class QuorumManager {

    // URLs das infraestruturas descobertas via UDDI
    private List<String> infraUrls;

    // N = total de réplicas, Qr = quorum leitura, Qw = quorum escrita
    private int N, Qr, Qw;

    // Contador global de sequência para escritas
    private int globalSeq = 0;

    public QuorumManager(List<String> infraUrls) {
        this.infraUrls = infraUrls;
        this.N  = infraUrls.size();
        this.Qr = (N / 2) + 1; // maioria simples
        this.Qw = (N / 2) + 1;
        System.out.println("QuorumManager iniciado: N=" + N + " Qr=" + Qr + " Qw=" + Qw);
    }

    // Lê o saldo com quorum — devolve o valor mais recente
    public int lerSaldoQuorum(String email) {
        List<int[]> respostas = new ArrayList<>();

        // Pergunta a todas as infraestruturas em paralelo
        ExecutorService executor = Executors.newFixedThreadPool(N);
        List<Future<int[]>> futures = new ArrayList<>();

        for (String url : infraUrls) {
            futures.add(executor.submit(() -> {
                try {
                    InfrastructurePortType port = getPort(url);
                    return port.lerSaldo(email);
                } catch (Exception e) {
                    System.err.println("Réplica inacessível: " + url);
                    return null;
                }
            }));
        }

        // Recolhe respostas até atingir quorum
        for (Future<int[]> f : futures) {
            try {
                int[] resp = f.get(2, TimeUnit.SECONDS);
                if (resp != null) respostas.add(resp);
                if (respostas.size() >= Qr) break; // quorum atingido!
            } catch (Exception e) {
                // réplica não respondeu a tempo
            }
        }
        executor.shutdown();

        if (respostas.size() < Qr) {
            throw new RuntimeException("Quorum não atingido — réplicas insuficientes a responder");
        }

        // Escolhe o valor com o sequenceNumber mais alto (mais recente)
        return respostas.stream()
            .max(Comparator.comparingInt(r -> r[1]))
            .map(r -> r[0])
            .orElse(10); // saldo inicial por omissão
    }

    // Escreve o saldo com quorum — garante que Qw réplicas confirmam
    public void escreverSaldoQuorum(String email, int novoSaldo) {
        globalSeq++; // incrementa o número de sequência global
        final int seq = globalSeq;
        int confirmacoes = 0;

        ExecutorService executor = Executors.newFixedThreadPool(N);
        List<Future<String>> futures = new ArrayList<>();

        for (String url : infraUrls) {
            futures.add(executor.submit(() -> {
                try {
                    InfrastructurePortType port = getPort(url);
                    return port.escreverSaldo(email, novoSaldo, seq);
                } catch (Exception e) {
                    System.err.println("Falha ao escrever em réplica: " + url);
                    return "ERRO";
                }
            }));
        }

        // Conta confirmações
        for (Future<String> f : futures) {
            try {
                String resp = f.get(2, TimeUnit.SECONDS);
                if ("OK".equals(resp)) confirmacoes++;
                if (confirmacoes >= Qw) break; // quorum de escrita atingido!
            } catch (Exception e) {
                // réplica não respondeu
            }
        }
        executor.shutdown();

        if (confirmacoes < Qw) {
            throw new RuntimeException("Quorum de escrita não atingido — apenas "
                + confirmacoes + " de " + Qw + " confirmações");
        }

        System.out.println("Escrita com quorum OK: " + email + " = " + novoSaldo
            + " (seq=" + seq + ", confirmações=" + confirmacoes + ")");
    }

    // Cria um cliente JAX-WS para uma infraestrutura
    private InfrastructurePortType getPort(String url) throws Exception {
        URL wsdlUrl = new URL(url + "?wsdl");
        QName qname = new QName(
            "http://infrastructure.anunciosloc.uan.pt/",
            "InfrastructureService"
        );
        Service service = Service.create(wsdlUrl, qname);
        return service.getPort(InfrastructurePortType.class);
    }
}