package pt.uan.anunciosloc.client;

import javax.jws.WebMethod;
import javax.jws.WebService;

/**
 * SEI alinhada com o WSDL publicado por {@link pt.uan.anunciosloc.server.AnunciosLocEndpoint}.
 */
@WebService(name = "AnunciosLoc", targetNamespace = "http://server.anunciosloc.uan.pt/")
public interface AnunciosLocPortType {

    @WebMethod
    String ativarUtilizador(String email);

    @WebMethod
    String postarMensagem(String email, String localName, String texto);

    @WebMethod
    String receberMensagem(String email, String localName);

    @WebMethod
    String listarAnunciosEntregues(String email);

    @WebMethod
    int consultarSaldo(String email);

    @WebMethod
    String ping();

    @WebMethod
    void clear();
}
