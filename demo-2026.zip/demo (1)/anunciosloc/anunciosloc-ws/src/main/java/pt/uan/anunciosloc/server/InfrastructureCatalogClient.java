package pt.uan.anunciosloc.server;

import pt.uan.anunciosloc.infrastructure.UDDIHelper;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Descobre URLs de serviços {@code Infrastructure} via UDDI / registo local e consulta cada SOAP
 * {@code obterInfoInfraestrutura} para listar e ordenar por distância.
 */
final class InfrastructureCatalogClient {

    private static final int CONNECT_MS = 2_000;
    private static final int READ_MS = 5_000;

    private static final Pattern SOAP_RETURN = Pattern.compile(
        "<[^/>:]*:?return\\b[^>]*>([\\s\\S]*?)</[^/>:]*:?return\\s*>",
        Pattern.CASE_INSENSITIVE
    );

    private static final Pattern INFO_GPS = Pattern.compile(
        "Nome:\\s*([^|]+?)\\s*\\|\\s*GPS:\\s*\\[([-\\d.,]+),\\s*([-\\d.,]+),\\s*(\\d+)m\\]"
    );

    /** Raio por omissão para infra registada só pela app (GPS impreciso). */
    private static final int DEFAULT_RADIUS_CATALOG_M = 100;

    static final class InfraGeo {
        final String nome;
        final double lat;
        final double lon;
        final int radiusMeters;
        final String url;

        InfraGeo(String nome, double lat, double lon, int radiusMeters, String url) {
            this.nome = nome;
            this.lat = lat;
            this.lon = lon;
            this.radiusMeters = radiusMeters;
            this.url = url;
        }
    }

    /**
     * Devolve a infraestrutura em que o utilizador se encontra (dentro do raio GPS), ou {@code null}.
     */
    static InfraGeo resolveNaPosicao(double userLat, double userLon) {
        List<InfraGeo> todas = carregarTodas();
        InfraGeo melhor = null;
        double melhorDistM = Double.MAX_VALUE;
        for (InfraGeo ig : todas) {
            double distM = haversineKm(userLat, userLon, ig.lat, ig.lon) * 1000.0;
            if (distM <= ig.radiusMeters && distM < melhorDistM) {
                melhor = ig;
                melhorDistM = distM;
            }
        }
        return melhor;
    }

    /** Replica o anúncio no nó SOAP da infraestrutura (best-effort). */
    static void encaminharParaInfra(String serviceUrl, String emailAutor, String texto) {
        if (serviceUrl == null || serviceUrl.isBlank()) {
            return;
        }
        String base = normalizarUrlServico(serviceUrl);
        if (base == null || base.contains("?")) {
            // URL só de catálogo (sem servidor activo)
            return;
        }
        try {
            String escEmail = escapeXml(emailAutor == null ? "" : emailAutor);
            String escTexto = escapeXml(texto == null ? "" : texto);
            String body = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                + "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" "
                + "xmlns:inf=\"http://infrastructure.anunciosloc.uan.pt/\">"
                + "<soapenv:Body><inf:postarAnuncio>"
                + "<arg0>" + escEmail + "</arg0>"
                + "<arg1>" + escTexto + "</arg1>"
                + "</inf:postarAnuncio></soapenv:Body></soapenv:Envelope>";
            postSoapRaw(base, body);
        } catch (Exception e) {
            System.err.println("AVISO: não foi possível replicar anúncio em " + base + ": " + e.getMessage());
        }
    }

    private static String escapeXml(String s) {
        return s.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;");
    }

    private static List<InfraGeo> carregarTodas() {
        List<InfraGeo> out = new ArrayList<>();
        LinkedHashSet<String> urls = new LinkedHashSet<>(UDDIHelper.pesquisar("Infrastructure"));
        for (String raw : urls) {
            String base = normalizarUrlServico(raw);
            if (base == null) {
                continue;
            }
            InfraGeo fromUrl = infraFromUrlCatalogo(base);
            if (fromUrl != null) {
                out.add(fromUrl);
                continue;
            }
            try {
                String xml = postSoapObterInfo(base);
                String info = extrairReturn(xml);
                if (info == null || info.isBlank()) {
                    continue;
                }
                Matcher m = INFO_GPS.matcher(info);
                if (m.find()) {
                    out.add(new InfraGeo(
                        m.group(1).trim(),
                        parseCoord(m.group(2)),
                        parseCoord(m.group(3)),
                        Integer.parseInt(m.group(4)),
                        base
                    ));
                }
            } catch (Exception ignored) {
                // infra inacessível — ignora
            }
        }
        return out;
    }

    private InfrastructureCatalogClient() {}

    static String listarOrdenadoPorDistancia(double lat, double lon, int k) {
        int top = Math.max(1, k);
        LinkedHashSet<String> urls = new LinkedHashSet<>(UDDIHelper.pesquisar("Infrastructure"));
        if (urls.isEmpty()) {
            return cabecalho(lat, lon, top)
                + "  (Nenhuma infraestrutura registada. Arranca infrastructure-ws para registar no UDDI ou no ficheiro local.)\n";
        }

        List<InfraLinha> linhas = new ArrayList<>();
        for (String raw : urls) {
            String base = normalizarUrlServico(raw);
            if (base == null) {
                continue;
            }
            InfraLinha catalogo = linhaFromUrlCatalogo(base, lat, lon);
            if (catalogo != null) {
                linhas.add(catalogo);
                continue;
            }
            try {
                String xml = postSoapObterInfo(base);
                String info = extrairReturn(xml);
                if (info == null || info.isBlank()) {
                    linhas.add(InfraLinha.fallback(base, "Resposta SOAP sem texto"));
                    continue;
                }
                Matcher m = INFO_GPS.matcher(info);
                if (m.find()) {
                    String nome = m.group(1).trim();
                    double ilat = parseCoord(m.group(2));
                    double ilon = parseCoord(m.group(3));
                    double km = haversineKm(lat, lon, ilat, ilon);
                    linhas.add(new InfraLinha(nome, km, base));
                } else {
                    linhas.add(InfraLinha.fallback(base, info.length() > 80 ? info.substring(0, 80) + "…" : info));
                }
            } catch (Exception e) {
                linhas.add(InfraLinha.fallback(base, e.getMessage() == null ? "inacessível" : e.getMessage()));
            }
        }

        if (linhas.isEmpty()) {
            return cabecalho(lat, lon, top)
                + "  (Nenhum URL de infraestrutura válido encontrado.)\n";
        }

        linhas.sort(Comparator.comparingDouble(InfraLinha::distanciaKm));
        StringBuilder sb = new StringBuilder(cabecalho(lat, lon, top));
        int n = Math.min(top, linhas.size());
        for (int i = 0; i < n; i++) {
            InfraLinha L = linhas.get(i);
            sb.append("  ")
                .append(i + 1)
                .append(". ")
                .append(L.nome)
                .append(" — ")
                .append(String.format(Locale.ROOT, "%.2f", L.distanciaKm))
                .append(" km — ")
                .append(L.url)
                .append("\n");
        }
        return sb.toString();
    }

    static String obterInfoPorNomeOuUrl(String needle) throws Exception {
        String n = needle.trim().toLowerCase(Locale.ROOT);
        LinkedHashSet<String> urls = new LinkedHashSet<>(UDDIHelper.pesquisar("Infrastructure"));
        for (String raw : urls) {
            String base = normalizarUrlServico(raw);
            if (base == null) {
                continue;
            }
            try {
                String xml = postSoapObterInfo(base);
                String info = extrairReturn(xml);
                if (info == null || info.isBlank()) {
                    continue;
                }
                if (info.toLowerCase(Locale.ROOT).contains(n) || base.toLowerCase(Locale.ROOT).contains(n)) {
                    return info;
                }
                Matcher m = INFO_GPS.matcher(info);
                if (m.find() && m.group(1).trim().toLowerCase(Locale.ROOT).contains(n)) {
                    return info;
                }
            } catch (Exception ignored) {
                // tenta próximo URL
            }
        }
        return "ERRO: infraestrutura não encontrada para '" + needle + "'";
    }

    private static double parseCoord(String raw) {
        return Double.parseDouble(raw.trim().replace(',', '.'));
    }

    /** Entradas registadas pela app (URL com ?lat=&lon=&nome=) sem servidor SOAP activo. */
    private static InfraGeo infraFromUrlCatalogo(String base) {
        try {
            URI uri = URI.create(base.split("#")[0]);
            String query = uri.getRawQuery();
            if (query == null || !query.contains("lat=") || !query.contains("lon=")) {
                return null;
            }
            double ilat = 0;
            double ilon = 0;
            int radius = DEFAULT_RADIUS_CATALOG_M;
            String nome = "Infraestrutura";
            for (String part : query.split("&")) {
                String[] kv = part.split("=", 2);
                if (kv.length != 2) {
                    continue;
                }
                String key = URLDecoder.decode(kv[0], StandardCharsets.UTF_8);
                String val = URLDecoder.decode(kv[1], StandardCharsets.UTF_8);
                if ("lat".equalsIgnoreCase(key)) {
                    ilat = parseCoord(val);
                } else if ("lon".equalsIgnoreCase(key)) {
                    ilon = parseCoord(val);
                } else if ("nome".equalsIgnoreCase(key)) {
                    nome = val;
                } else if ("radius".equalsIgnoreCase(key)) {
                    radius = Integer.parseInt(val.trim());
                }
            }
            return new InfraGeo(nome, ilat, ilon, radius, base);
        } catch (Exception e) {
            return null;
        }
    }

    /** @deprecated use {@link #infraFromUrlCatalogo} */
    private static InfraLinha linhaFromUrlCatalogo(String base, double userLat, double userLon) {
        InfraGeo geo = infraFromUrlCatalogo(base);
        if (geo == null) {
            return null;
        }
        double km = haversineKm(userLat, userLon, geo.lat, geo.lon);
        return new InfraLinha(geo.nome, km, base);
    }

    private static String cabecalho(double lat, double lon, int k) {
        return "Infraestruturas mais próximas de ["
            + lat + ", " + lon + "] (top " + k + "):\n";
    }

    private static String normalizarUrlServico(String raw) {
        if (raw == null) {
            return null;
        }
        String u = raw.trim();
        if (u.isEmpty()) {
            return null;
        }
        if (u.endsWith("?wsdl")) {
            u = u.substring(0, u.length() - 5);
        }
        if (u.endsWith("/")) {
            u = u.substring(0, u.length() - 1);
        }
        return u;
    }

    private static String postSoapObterInfo(String serviceUrl) throws Exception {
        String body = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
            + "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" "
            + "xmlns:inf=\"http://infrastructure.anunciosloc.uan.pt/\">"
            + "<soapenv:Body><inf:obterInfoInfraestrutura/></soapenv:Body></soapenv:Envelope>";
        return postSoapRaw(serviceUrl, body);
    }

    private static String postSoapRaw(String serviceUrl, String body) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(serviceUrl).openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(CONNECT_MS);
        conn.setReadTimeout(READ_MS);
        conn.setRequestProperty("Content-Type", "text/xml;charset=UTF-8");
        conn.setRequestProperty("SOAPAction", "");
        conn.setDoOutput(true);
        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.getBytes(StandardCharsets.UTF_8));
        }
        int code = conn.getResponseCode();
        StringBuilder out = new StringBuilder();
        java.io.InputStream in = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
        if (in == null) {
            throw new IllegalStateException("HTTP " + code + " (sem corpo de resposta)");
        }
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                out.append(line).append('\n');
            }
        }
        if (code >= 400) {
            throw new IllegalStateException("HTTP " + code + ": " + out.toString().trim());
        }
        return out.toString();
    }

    private static String extrairReturn(String xml) {
        if (xml == null) {
            return null;
        }
        Matcher m = SOAP_RETURN.matcher(xml);
        return m.find() ? unescapeXml(m.group(1).trim()) : null;
    }

    private static String unescapeXml(String s) {
        return s.replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&amp;", "&")
            .replace("&quot;", "\"")
            .replace("&apos;", "'");
    }

    private static double haversineKm(double lat1, double lon1, double lat2, double lon2) {
        final double R = 6371.0;
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
            + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
            * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    }

    private static final class InfraLinha {
        final String nome;
        final double distanciaKm;
        final String url;

        InfraLinha(String nome, double distanciaKm, String url) {
            this.nome = nome;
            this.distanciaKm = distanciaKm;
            this.url = url;
        }

        static InfraLinha fallback(String url, String motivo) {
            String nome = "Infraestrutura (" + motivo + ")";
            return new InfraLinha(nome, Double.POSITIVE_INFINITY, url);
        }

        double distanciaKm() {
            return distanciaKm;
        }
    }
}
