package pt.uan.anunciosloc.server;

public class Utilizador {

    private String email;
    private int saldo;
    private long ultimoAnuncio; // timestamp em milissegundos

    public Utilizador(String email) {
        this(email, 10, System.currentTimeMillis());
    }

    /** Carrega estado persistido (PostgreSQL). */
    public Utilizador(String email, int saldo, long ultimoAnuncioMs) {
        this.email = email;
        this.saldo = saldo;
        this.ultimoAnuncio = ultimoAnuncioMs;
    }

    public String getEmail() { return email; }

    public int getSaldo() { return saldo; }

    public void setSaldo(int saldo) { this.saldo = saldo; }

    public void adicionarSaldo(int bonus) { this.saldo += bonus; }

    public void decrementarSaldo() { this.saldo -= 1; }

    public long getUltimoAnuncio() { return ultimoAnuncio; }

    public void atualizarUltimoAnuncio() {
        this.ultimoAnuncio = System.currentTimeMillis();
    }
}
