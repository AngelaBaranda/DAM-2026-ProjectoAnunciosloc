package pt.uan.anunciosloc.server;

import com.sun.net.httpserver.Filter;
import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpContext;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.util.Collections;
import javax.xml.ws.Endpoint;
import pt.uan.anunciosloc.infrastructure.UDDIHelper;

public class AnunciosLocServer {

    public static void main(String[] args) throws Exception {

        String groupId     = "D01"; // altera para o teu grupo!
        String serviceName = groupId + "_AnunciosLoc";
        int port = 8080;
        String path = "/anunciosloc";
        String serviceUrl  = "http://localhost:" + port + path;

        System.out.println("A ligar ao PostgreSQL...");
        System.out.println("  JDBC URL: " + System.getenv().getOrDefault("ANUNCIOSLOC_JDBC_URL", "jdbc:postgresql://localhost:5432/anunciosloc"));
        System.out.println("  JDBC USER: " + System.getenv().getOrDefault("ANUNCIOSLOC_JDBC_USER", "postgres"));
        AnunciosLocDb.init();

        // 1. Lança o Web Service com CORS para o frontend web
        AnunciosLocEndpoint service = new AnunciosLocEndpoint();
        Endpoint endpoint = Endpoint.create(service);
        HttpServer httpServer = HttpServer.create(new InetSocketAddress(port), 0);
        // Trata pedidos OPTIONS em qualquer caminho (ex.: ?wsdl) sem chegar ao handler JAX-WS
        httpServer.createContext("/", new GlobalOptionsCorsHandler());
        HttpContext context = httpServer.createContext(path);
        context.getFilters().add(new CorsFilter());
        endpoint.publish(context);
        httpServer.start();
        System.out.println("Servidor AnunciosLoc activo em: " + serviceUrl);
        System.out.println("WSDL: " + serviceUrl + "?wsdl");
        String lan = detectLanServiceUrl(port, path);
        if (lan != null) {
            System.out.println("Te móvel (mesma Wi‑Fi): " + lan + "  (emulador Android: http://10.0.2.2:" + port + path + ")");
        }

        // 2. Regista no UDDI
        try {
            UDDIHelper.registar(serviceName, serviceUrl);
        } catch (Exception e) {
            System.err.println("AVISO: registo UDDI falhou (servidor UDDI pode estar parado): " + e.getMessage());
        }

        if (System.console() != null) {
            System.out.println("Pronto! Prima ENTER para terminar...");
            System.in.read();
        } else {
            System.out.println("Modo serviço (sem consola): a correr até o processo ser terminado.");
            Thread.currentThread().join();
        }
        endpoint.stop();
        httpServer.stop(0);
    }

    private static String detectLanServiceUrl(int port, String path) {
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) {
                    continue;
                }
                for (var addr : Collections.list(ni.getInetAddresses())) {
                    if (addr instanceof Inet4Address && !addr.isLoopbackAddress()) {
                        return "http://" + addr.getHostAddress() + ":" + port + path;
                    }
                }
            }
        } catch (Exception ignored) {
            // ignora
        }
        return null;
    }

    private static class CorsFilter extends Filter {
        @Override
        public void doFilter(HttpExchange exchange, Chain chain) throws IOException {
            addCors(exchange.getResponseHeaders());

            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(204, -1);
                return;
            }

            chain.doFilter(exchange);
        }

        @Override
        public String description() {
            return "Adds CORS headers for browser SOAP calls";
        }
    }

    private static void addCors(Headers headers) {
        headers.set("Access-Control-Allow-Origin", "*");
        headers.set("Access-Control-Allow-Methods", "POST, GET, OPTIONS");
        headers.set("Access-Control-Allow-Headers", "Content-Type, SOAPAction, Accept");
    }

    /**
     * Responde a OPTIONS globalmente para evitar warnings do JAX-WS em pedidos preflight
     * que não batem exactamente no contexto do serviço.
     */
    private static class GlobalOptionsCorsHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!"OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(404, -1);
                return;
            }
            addCors(exchange.getResponseHeaders());
            exchange.sendResponseHeaders(204, -1);
        }
    }
}
