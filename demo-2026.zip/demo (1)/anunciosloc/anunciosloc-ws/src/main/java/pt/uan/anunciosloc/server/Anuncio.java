package pt.uan.anunciosloc.server;

public class Anuncio {

    private String id;
    private String emailAutor;
    private String texto;
    private String localName;
    private long timestamp;

    public Anuncio(String emailAutor, String texto, String localName) {
        this(java.util.UUID.randomUUID().toString(), emailAutor, texto, localName, System.currentTimeMillis());
    }

    /** Anúncio carregado da base de dados. */
    public Anuncio(String id, String emailAutor, String texto, String localName, long timestampMs) {
        this.id = id;
        this.emailAutor = emailAutor;
        this.texto = texto;
        this.localName = localName;
        this.timestamp = timestampMs;
    }

    public String getId()         { return id; }
    public String getEmailAutor() { return emailAutor; }
    public String getTexto()      { return texto; }
    public String getLocalName()  { return localName; }
    public long   getTimestamp()  { return timestamp; }

    @Override
    public String toString() {
        return "[" + localName + "] " + emailAutor + ": " + texto;
    }
}