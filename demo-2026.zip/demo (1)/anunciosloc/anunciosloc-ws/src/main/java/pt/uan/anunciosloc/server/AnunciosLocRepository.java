package pt.uan.anunciosloc.server;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

final class AnunciosLocRepository {
    static final class UserAuth {
        final String nome;
        final String senha;
        final int saldo;

        UserAuth(String nome, String senha, int saldo) {
            this.nome = nome;
            this.senha = senha;
            this.saldo = saldo;
        }
    }

    void clearAll() throws Exception {
        try (Connection c = AnunciosLocDb.getConnection()) {
            c.setAutoCommit(false);
            try (PreparedStatement st0 = c.prepareStatement("DELETE FROM entregas");
                 PreparedStatement stChat = c.prepareStatement("DELETE FROM mensagens_chat");
                 PreparedStatement st1 = c.prepareStatement("DELETE FROM anuncios");
                 PreparedStatement st2 = c.prepareStatement("DELETE FROM utilizadores")) {
                try {
                    st0.executeUpdate();
                } catch (java.sql.SQLException ex) {
                    if (!"42P01".equals(ex.getSQLState())) {
                        throw ex;
                    }
                }
                try {
                    stChat.executeUpdate();
                } catch (java.sql.SQLException ex) {
                    if (!"42P01".equals(ex.getSQLState())) {
                        throw ex;
                    }
                }
                st1.executeUpdate();
                st2.executeUpdate();
                try (PreparedStatement st3 = c.prepareStatement(
                    "INSERT INTO dashboard_metricas (chave, valor) VALUES ('entregas', 0) "
                        + "ON CONFLICT (chave) DO UPDATE SET valor = 0")) {
                    st3.executeUpdate();
                } catch (java.sql.SQLException ex) {
                    if (!"42P01".equals(ex.getSQLState())) {
                        throw ex;
                    }
                    // tabela dashboard_metricas ainda não existe — ignorar
                }
                c.commit();
            } catch (Exception e) {
                c.rollback();
                throw e;
            }
        }
    }

    boolean userExists(String email) throws Exception {
        try (Connection c = AnunciosLocDb.getConnection();
             PreparedStatement st = c.prepareStatement("SELECT 1 FROM utilizadores WHERE email = ?")) {
            st.setString(1, email);
            try (ResultSet rs = st.executeQuery()) {
                return rs.next();
            }
        }
    }

    void insertUser(String email, int saldoInicial, long ultimoAnuncioMs) throws Exception {
        try (Connection c = AnunciosLocDb.getConnection();
             PreparedStatement st = c.prepareStatement(
                 "INSERT INTO utilizadores(email, saldo, ultimo_anuncio_ms) VALUES (?,?,?)")) {
            st.setString(1, email);
            st.setInt(2, saldoInicial);
            st.setLong(3, ultimoAnuncioMs);
            st.executeUpdate();
        }
    }

    void insertUserWithAuth(String email, String nome, String senha, int saldoInicial, long ultimoAnuncioMs) throws Exception {
        try (Connection c = AnunciosLocDb.getConnection();
             PreparedStatement st = c.prepareStatement(
                 "INSERT INTO utilizadores(email, nome, senha, saldo, ultimo_anuncio_ms) VALUES (?,?,?,?,?)")) {
            st.setString(1, email);
            st.setString(2, nome);
            st.setString(3, senha);
            st.setInt(4, saldoInicial);
            st.setLong(5, ultimoAnuncioMs);
            st.executeUpdate();
        }
    }

    String findEmailByNome(String nome) throws Exception {
        if (nome == null || nome.isBlank()) {
            return null;
        }
        try (Connection c = AnunciosLocDb.getConnection();
             PreparedStatement st = c.prepareStatement(
                 "SELECT email FROM utilizadores WHERE LOWER(TRIM(nome)) = LOWER(TRIM(?))")) {
            st.setString(1, nome);
            try (ResultSet rs = st.executeQuery()) {
                return rs.next() ? rs.getString(1) : null;
            }
        }
    }

    UserAuth loadUserAuth(String email) throws Exception {
        try (Connection c = AnunciosLocDb.getConnection();
             PreparedStatement st = c.prepareStatement(
                 "SELECT nome, senha, saldo FROM utilizadores WHERE email = ?")) {
            st.setString(1, email);
            try (ResultSet rs = st.executeQuery()) {
                if (!rs.next()) {
                    return null;
                }
                return new UserAuth(rs.getString("nome"), rs.getString("senha"), rs.getInt("saldo"));
            }
        }
    }

    Utilizador loadUser(String email) throws Exception {
        try (Connection c = AnunciosLocDb.getConnection();
             PreparedStatement st = c.prepareStatement(
                 "SELECT email, saldo, ultimo_anuncio_ms FROM utilizadores WHERE email = ?")) {
            st.setString(1, email);
            try (ResultSet rs = st.executeQuery()) {
                if (!rs.next()) {
                    return null;
                }
                return new Utilizador(
                    rs.getString("email"),
                    rs.getInt("saldo"),
                    rs.getLong("ultimo_anuncio_ms")
                );
            }
        }
    }

    void updateUserLastPost(String email, long ultimoAnuncioMs) throws Exception {
        try (Connection c = AnunciosLocDb.getConnection();
             PreparedStatement st = c.prepareStatement(
                 "UPDATE utilizadores SET ultimo_anuncio_ms = ? WHERE email = ?")) {
            st.setLong(1, ultimoAnuncioMs);
            st.setString(2, email);
            st.executeUpdate();
        }
    }

    void addSaldo(String email, int delta) throws Exception {
        try (Connection c = AnunciosLocDb.getConnection();
             PreparedStatement st = c.prepareStatement(
                 "UPDATE utilizadores SET saldo = saldo + ? WHERE email = ?")) {
            st.setInt(1, delta);
            st.setString(2, email);
            st.executeUpdate();
        }
    }

    int getSaldo(String email) throws Exception {
        try (Connection c = AnunciosLocDb.getConnection();
             PreparedStatement st = c.prepareStatement("SELECT saldo FROM utilizadores WHERE email = ?")) {
            st.setString(1, email);
            try (ResultSet rs = st.executeQuery()) {
                if (!rs.next()) {
                    return -1;
                }
                return rs.getInt("saldo");
            }
        }
    }

    Anuncio insertAd(String emailAutor, String localName, String texto) throws Exception {
        UUID id = UUID.randomUUID();
        try (Connection c = AnunciosLocDb.getConnection();
             PreparedStatement st = c.prepareStatement(
                 "INSERT INTO anuncios(id, email_autor, local_name, texto) VALUES (?,?,?,?) "
                     + "RETURNING created_at")) {
            st.setObject(1, id);
            st.setString(2, emailAutor);
            st.setString(3, localName);
            st.setString(4, texto);
            try (ResultSet rs = st.executeQuery()) {
                if (!rs.next()) {
                    throw new IllegalStateException("INSERT sem RETURNING");
                }
                Timestamp ts = rs.getTimestamp("created_at");
                long ms = ts != null ? ts.getTime() : System.currentTimeMillis();
                return new Anuncio(id.toString(), emailAutor, texto, localName, ms);
            }
        }
    }

    List<Anuncio> listAdsByLocal(String localName) throws Exception {
        try (Connection c = AnunciosLocDb.getConnection();
             PreparedStatement st = c.prepareStatement(
                 "SELECT id, email_autor, local_name, texto, created_at "
                     + "FROM anuncios WHERE local_name = ? ORDER BY created_at ASC")) {
            st.setString(1, localName);
            try (ResultSet rs = st.executeQuery()) {
                List<Anuncio> list = new ArrayList<>();
                while (rs.next()) {
                    String id = rs.getObject("id", UUID.class).toString();
                    String autor = rs.getString("email_autor");
                    String local = rs.getString("local_name");
                    String texto = rs.getString("texto");
                    Timestamp ts = rs.getTimestamp("created_at");
                    long ms = ts != null ? ts.getTime() : System.currentTimeMillis();
                    list.add(new Anuncio(id, autor, texto, local, ms));
                }
                return list;
            }
        }
    }

    Map<String, Utilizador> loadAllUsers() throws Exception {
        Map<String, Utilizador> map = new HashMap<>();
        try (Connection c = AnunciosLocDb.getConnection();
             PreparedStatement st = c.prepareStatement(
                 "SELECT email, saldo, ultimo_anuncio_ms FROM utilizadores");
             ResultSet rs = st.executeQuery()) {
            while (rs.next()) {
                String email = rs.getString("email");
                map.put(email, new Utilizador(email, rs.getInt("saldo"), rs.getLong("ultimo_anuncio_ms")));
            }
        }
        return map;
    }

    Map<String, List<Anuncio>> loadAllAdsGroupedByLocal() throws Exception {
        Map<String, List<Anuncio>> map = new HashMap<>();
        try (Connection c = AnunciosLocDb.getConnection();
             PreparedStatement st = c.prepareStatement(
                 "SELECT id, email_autor, local_name, texto, created_at FROM anuncios ORDER BY created_at ASC");
             ResultSet rs = st.executeQuery()) {
            while (rs.next()) {
                String id = rs.getObject("id", UUID.class).toString();
                String autor = rs.getString("email_autor");
                String local = rs.getString("local_name");
                String texto = rs.getString("texto");
                Timestamp ts = rs.getTimestamp("created_at");
                long ms = ts != null ? ts.getTime() : System.currentTimeMillis();
                map.computeIfAbsent(local, k -> new ArrayList<>())
                    .add(new Anuncio(id, autor, texto, local, ms));
            }
        }
        return map;
    }

    int countUsers() throws Exception {
        try (Connection c = AnunciosLocDb.getConnection();
             PreparedStatement st = c.prepareStatement("SELECT COUNT(*) FROM utilizadores");
             ResultSet rs = st.executeQuery()) {
            rs.next();
            return rs.getInt(1);
        }
    }

    int countDistinctLocalsWithAds() throws Exception {
        try (Connection c = AnunciosLocDb.getConnection();
             PreparedStatement st = c.prepareStatement("SELECT COUNT(DISTINCT local_name) FROM anuncios");
             ResultSet rs = st.executeQuery()) {
            rs.next();
            return rs.getInt(1);
        }
    }

    int countAds() throws Exception {
        try (Connection c = AnunciosLocDb.getConnection();
             PreparedStatement st = c.prepareStatement("SELECT COUNT(*) FROM anuncios");
             ResultSet rs = st.executeQuery()) {
            rs.next();
            return rs.getInt(1);
        }
    }

    long getMetric(String chave) throws Exception {
        try (Connection c = AnunciosLocDb.getConnection();
             PreparedStatement st = c.prepareStatement(
                 "SELECT valor FROM dashboard_metricas WHERE chave = ?")) {
            st.setString(1, chave);
            try (ResultSet rs = st.executeQuery()) {
                if (!rs.next()) {
                    return 0L;
                }
                return rs.getLong(1);
            }
        }
    }

    void addMetric(String chave, long delta) throws Exception {
        try (Connection c = AnunciosLocDb.getConnection();
             PreparedStatement st = c.prepareStatement(
                 "INSERT INTO dashboard_metricas (chave, valor) VALUES (?, ?) "
                     + "ON CONFLICT (chave) DO UPDATE SET valor = dashboard_metricas.valor + EXCLUDED.valor")) {
            st.setString(1, chave);
            st.setLong(2, delta);
            st.executeUpdate();
        }
    }

    int countAdsByAuthor(String email) throws Exception {
        try (Connection c = AnunciosLocDb.getConnection();
             PreparedStatement st = c.prepareStatement(
                 "SELECT COUNT(*) FROM anuncios WHERE email_autor = ?")) {
            st.setString(1, email);
            try (ResultSet rs = st.executeQuery()) {
                rs.next();
                return rs.getInt(1);
            }
        }
    }

    long getEntregasUtilizador(String email) throws Exception {
        return countEntregasForUser(email);
    }

    void addEntregasUtilizador(String email, long delta) throws Exception {
        addMetric("entregas:" + email, delta);
    }

    void syncMetricEntregasUtilizador(String email) throws Exception {
        setMetric("entregas:" + email, countEntregasForUser(email));
    }

    int countEntregasForUser(String email) throws Exception {
        try (Connection c = AnunciosLocDb.getConnection();
             PreparedStatement st = c.prepareStatement(
                 "SELECT COUNT(*) FROM entregas WHERE email_destinatario = ?")) {
            st.setString(1, email);
            try (ResultSet rs = st.executeQuery()) {
                rs.next();
                return rs.getInt(1);
            }
        }
    }

    /**
     * Alinha a métrica do perfil com o número real de entregas na BD (sem duplicar linhas).
     */
    void reconcileEntregasMetric(String email) throws Exception {
        syncMetricEntregasUtilizador(email);
    }

    void syncMetricEntregasGlobal() throws Exception {
        try (Connection c = AnunciosLocDb.getConnection();
             PreparedStatement st = c.prepareStatement("SELECT COUNT(*) FROM entregas");
             ResultSet rs = st.executeQuery()) {
            rs.next();
            setMetric("entregas", rs.getLong(1));
        }
    }

    void setMetric(String chave, long valor) throws Exception {
        try (Connection c = AnunciosLocDb.getConnection();
             PreparedStatement st = c.prepareStatement(
                 "INSERT INTO dashboard_metricas (chave, valor) VALUES (?, ?) "
                     + "ON CONFLICT (chave) DO UPDATE SET valor = EXCLUDED.valor")) {
            st.setString(1, chave);
            st.setLong(2, valor);
            st.executeUpdate();
        }
    }

    /** @return true se a entrega foi registada agora; false se já existia para este utilizador/anúncio */
    boolean recordEntrega(String emailDestinatario, Anuncio anuncio) throws Exception {
        try (Connection c = AnunciosLocDb.getConnection();
             PreparedStatement st = c.prepareStatement(
                 "INSERT INTO entregas(email_destinatario, anuncio_id, local_name, texto, email_autor) "
                     + "VALUES (?, ?::uuid, ?, ?, ?) "
                     + "ON CONFLICT (email_destinatario, anuncio_id) DO NOTHING")) {
            st.setString(1, emailDestinatario);
            st.setString(2, anuncio.getId());
            st.setString(3, anuncio.getLocalName());
            st.setString(4, anuncio.getTexto());
            st.setString(5, anuncio.getEmailAutor());
            return st.executeUpdate() > 0;
        }
    }

    static final class EntregaRegisto {
        final String localName;
        final String emailAutor;
        final String texto;
        final long entregueEmMs;

        EntregaRegisto(String localName, String emailAutor, String texto, long entregueEmMs) {
            this.localName = localName;
            this.emailAutor = emailAutor;
            this.texto = texto;
            this.entregueEmMs = entregueEmMs;
        }
    }

    List<EntregaRegisto> listEntregasForUser(String email) throws Exception {
        try (Connection c = AnunciosLocDb.getConnection();
             PreparedStatement st = c.prepareStatement(
                 "SELECT local_name, email_autor, texto, entregue_em FROM ("
                     + "SELECT DISTINCT ON (anuncio_id) local_name, email_autor, texto, entregue_em "
                     + "FROM entregas WHERE email_destinatario = ? "
                     + "ORDER BY anuncio_id, entregue_em DESC"
                     + ") sub ORDER BY entregue_em DESC")) {
            st.setString(1, email);
            try (ResultSet rs = st.executeQuery()) {
                List<EntregaRegisto> list = new ArrayList<>();
                while (rs.next()) {
                    Timestamp ts = rs.getTimestamp("entregue_em");
                    long ms = ts != null ? ts.getTime() : System.currentTimeMillis();
                    list.add(
                        new EntregaRegisto(
                            rs.getString("local_name"),
                            rs.getString("email_autor"),
                            rs.getString("texto"),
                            ms
                        )
                    );
                }
                return list;
            }
        }
    }

    List<String> listDistinctLocals() throws Exception {
        try (Connection c = AnunciosLocDb.getConnection();
             PreparedStatement st = c.prepareStatement(
                 "SELECT DISTINCT local_name FROM anuncios ORDER BY local_name");
             ResultSet rs = st.executeQuery()) {
            List<String> locais = new ArrayList<>();
            while (rs.next()) {
                locais.add(rs.getString(1));
            }
            return locais;
        }
    }

    static final class ChatMensagem {
        final String remetente;
        final String destinatario;
        final String texto;
        final long enviadaEmMs;

        ChatMensagem(String remetente, String destinatario, String texto, long enviadaEmMs) {
            this.remetente = remetente;
            this.destinatario = destinatario;
            this.texto = texto;
            this.enviadaEmMs = enviadaEmMs;
        }
    }

    void insertChatMessage(String remetente, String destinatario, String texto) throws Exception {
        try (Connection c = AnunciosLocDb.getConnection();
             PreparedStatement st = c.prepareStatement(
                 "INSERT INTO mensagens_chat(remetente_email, destinatario_email, texto) VALUES (?, ?, ?)")) {
            st.setString(1, remetente);
            st.setString(2, destinatario);
            st.setString(3, texto);
            st.executeUpdate();
        }
    }

    /** Última mensagem recebida (não enviada por mim) após o timestamp indicado. */
    ChatMensagem latestIncomingChatAfter(String emailDestinatario, long sinceMs) throws Exception {
        try (Connection c = AnunciosLocDb.getConnection();
             PreparedStatement st = c.prepareStatement(
                 "SELECT remetente_email, destinatario_email, texto, enviada_em "
                     + "FROM mensagens_chat "
                     + "WHERE destinatario_email = ? AND remetente_email <> ? "
                     + "AND enviada_em > to_timestamp(? / 1000.0) "
                     + "ORDER BY enviada_em DESC LIMIT 1")) {
            st.setString(1, emailDestinatario);
            st.setString(2, emailDestinatario);
            st.setLong(3, sinceMs);
            try (ResultSet rs = st.executeQuery()) {
                if (!rs.next()) {
                    return null;
                }
                Timestamp ts = rs.getTimestamp("enviada_em");
                long ms = ts != null ? ts.getTime() : System.currentTimeMillis();
                return new ChatMensagem(
                    rs.getString("remetente_email"),
                    rs.getString("destinatario_email"),
                    rs.getString("texto"),
                    ms
                );
            }
        }
    }

    EntregaRegisto latestEntregaForUser(String email) throws Exception {
        List<EntregaRegisto> list = listEntregasForUser(email);
        return list.isEmpty() ? null : list.get(0);
    }

    List<ChatMensagem> listChatMessages(String emailA, String emailB) throws Exception {
        try (Connection c = AnunciosLocDb.getConnection();
             PreparedStatement st = c.prepareStatement(
                 "SELECT remetente_email, destinatario_email, texto, enviada_em "
                     + "FROM mensagens_chat "
                     + "WHERE (remetente_email = ? AND destinatario_email = ?) "
                     + "OR (remetente_email = ? AND destinatario_email = ?) "
                     + "ORDER BY enviada_em ASC")) {
            st.setString(1, emailA);
            st.setString(2, emailB);
            st.setString(3, emailB);
            st.setString(4, emailA);
            try (ResultSet rs = st.executeQuery()) {
                List<ChatMensagem> list = new ArrayList<>();
                while (rs.next()) {
                    Timestamp ts = rs.getTimestamp("enviada_em");
                    long ms = ts != null ? ts.getTime() : System.currentTimeMillis();
                    list.add(
                        new ChatMensagem(
                            rs.getString("remetente_email"),
                            rs.getString("destinatario_email"),
                            rs.getString("texto"),
                            ms
                        )
                    );
                }
                return list;
            }
        }
    }
}
