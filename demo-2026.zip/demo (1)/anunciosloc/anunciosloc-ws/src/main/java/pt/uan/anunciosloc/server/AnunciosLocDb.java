package pt.uan.anunciosloc.server;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Locale;
import java.util.stream.Collectors;

/**
 * Ligação JDBC ao PostgreSQL. Configuração por propriedades/ambiente:
 * <ul>
 *   <li>{@code -DANUNCIOSLOC_JDBC_URL=...} (ou variável de ambiente)</li>
 *   <li>{@code -DANUNCIOSLOC_JDBC_USER=...} (ou variável de ambiente)</li>
 *   <li>{@code -DANUNCIOSLOC_JDBC_PASSWORD=...} (ou variável de ambiente / {@code PGPASSWORD})</li>
 * </ul>
 */
public final class AnunciosLocDb {

    private static final String URL =
        firstNonBlank(
            firstNonBlank(System.getProperty("ANUNCIOSLOC_JDBC_URL"), System.getenv("ANUNCIOSLOC_JDBC_URL")),
            "jdbc:postgresql://localhost:5432/anunciosloc"
        );
    private static final String USER =
        firstNonBlank(
            firstNonBlank(System.getProperty("ANUNCIOSLOC_JDBC_USER"), System.getenv("ANUNCIOSLOC_JDBC_USER")),
            "postgres"
        );
    private static final String PASSWORD =
        firstNonBlank(
            firstNonBlank(
                System.getProperty("ANUNCIOSLOC_JDBC_PASSWORD"),
                firstNonBlank(System.getenv("ANUNCIOSLOC_JDBC_PASSWORD"), System.getenv("PGPASSWORD"))
            ),
            ""
        );

    private AnunciosLocDb() {}

    public static void init() throws Exception {
        Class.forName("org.postgresql.Driver");
        if (URL.startsWith("jdbc:postgresql:") && (PASSWORD == null || PASSWORD.isEmpty())) {
            throw new IllegalStateException(
                "Password PostgreSQL em falta. Define ANUNCIOSLOC_JDBC_PASSWORD ou PGPASSWORD (SCRAM não aceita string vazia). "
                    + "Alternativa (dev): configurar pg_hba.conf para 'trust' para localhost — não recomendado fora de desenvolvimento."
            );
        }
        try (Connection c = getConnection()) {
            applySchema(c);
            migrateUtilizadoresIfNeeded(c);
            migrateAnunciosIfNeeded(c);
            migrateDashboardMetricsIfNeeded(c);
            migrateEntregasIfNeeded(c);
            migrateChatIfNeeded(c);
            createIndexesIfPossible(c);
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    private static void applySchema(Connection c) throws Exception {
        String sql;
        try (InputStream in = AnunciosLocDb.class.getResourceAsStream("/db/schema.sql")) {
            if (in == null) {
                throw new IllegalStateException("schema.sql não encontrado no classpath (/db/schema.sql)");
            }
            try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                sql = r.lines().collect(Collectors.joining("\n"));
            }
        }
        for (String stmt : splitSqlStatements(sql)) {
            if (stmt.isEmpty()) {
                continue;
            }
            try (Statement st = c.createStatement()) {
                st.execute(stmt);
            }
        }
    }

    private static void migrateUtilizadoresIfNeeded(Connection c) throws Exception {
        if (!tableExists(c, "utilizadores")) {
            return;
        }

        // Migra esquema antigo (ex.: ultimo_anuncio) -> esquema actual (ultimo_anuncio_ms)
        if (!columnExists(c, "utilizadores", "ultimo_anuncio_ms")
            && columnExists(c, "utilizadores", "ultimo_anuncio")) {
            exec(c, "ALTER TABLE utilizadores RENAME COLUMN ultimo_anuncio TO ultimo_anuncio_ms");
        }

        // Se a coluna vier de esquema antigo em timestamp, converte para epoch (ms).
        if (columnExists(c, "utilizadores", "ultimo_anuncio_ms")) {
            String type = columnDataType(c, "utilizadores", "ultimo_anuncio_ms");
            if (type != null && type.contains("timestamp")) {
                exec(c, "ALTER TABLE utilizadores ALTER COLUMN ultimo_anuncio_ms DROP DEFAULT");
                exec(
                    c,
                    "ALTER TABLE utilizadores "
                        + "ALTER COLUMN ultimo_anuncio_ms TYPE BIGINT "
                        + "USING (EXTRACT(EPOCH FROM ultimo_anuncio_ms) * 1000)::BIGINT"
                );
                exec(c, "ALTER TABLE utilizadores ALTER COLUMN ultimo_anuncio_ms SET DEFAULT 0");
            }
        }

        // Garante colunas essenciais no esquema actual (best-effort, preservando dados antigos)
        if (!columnExists(c, "utilizadores", "saldo")) {
            exec(c, "ALTER TABLE utilizadores ADD COLUMN saldo INTEGER NOT NULL DEFAULT 10");
        }
        if (!columnExists(c, "utilizadores", "nome")) {
            exec(c, "ALTER TABLE utilizadores ADD COLUMN nome VARCHAR(120) NOT NULL DEFAULT ''");
        }
        if (!columnExists(c, "utilizadores", "senha")) {
            exec(c, "ALTER TABLE utilizadores ADD COLUMN senha VARCHAR(255) NOT NULL DEFAULT ''");
        }
        if (!columnExists(c, "utilizadores", "ultimo_anuncio_ms")) {
            exec(c, "ALTER TABLE utilizadores ADD COLUMN ultimo_anuncio_ms BIGINT NOT NULL DEFAULT 0");
        }
    }

    private static void migrateAnunciosIfNeeded(Connection c) throws Exception {
        if (!tableExists(c, "anuncios")) {
            return;
        }

        // Migra esquema antigo (ex.: local_nome / autor_email / uuid) -> esquema actual
        if (!columnExists(c, "anuncios", "local_name") && columnExists(c, "anuncios", "local_nome")) {
            exec(c, "ALTER TABLE anuncios RENAME COLUMN local_nome TO local_name");
        }
        if (!columnExists(c, "anuncios", "email_autor") && columnExists(c, "anuncios", "autor_email")) {
            exec(c, "ALTER TABLE anuncios RENAME COLUMN autor_email TO email_autor");
        }
        if (!columnExists(c, "anuncios", "id") && columnExists(c, "anuncios", "uuid")) {
            exec(c, "ALTER TABLE anuncios RENAME COLUMN uuid TO id");
        }
        if (!columnExists(c, "anuncios", "created_at") && columnExists(c, "anuncios", "publicado_em")) {
            exec(c, "ALTER TABLE anuncios RENAME COLUMN publicado_em TO created_at");
        }

        // Esquema antigo com as duas colunas: os inserts JDBC só preenchem "id" → "uuid" NOT NULL falha.
        dropObsoleteAnunciosUuidColumnWhenIdAlsoExists(c);

        // id tem de ser UUID (o JDBC insere PreparedStatement#setObject(..., UUID)).
        // information_schema pode enganar; usamos também pg_catalog.
        ensureAnunciosIdIsUuidCompatible(c);

        // Garante NOT NULL/DEFAULT coerentes (best-effort)
        if (columnExists(c, "anuncios", "created_at")) {
            exec(c, "ALTER TABLE anuncios ALTER COLUMN created_at SET DEFAULT NOW()");
        }
    }

    /**
     * Remove {@code uuid} se {@code id} também existir (resto de migrações parciais). O código usa só {@code id}.
     */
    private static void dropObsoleteAnunciosUuidColumnWhenIdAlsoExists(Connection c) throws SQLException {
        if (!columnExists(c, "anuncios", "uuid") || !columnExists(c, "anuncios", "id")) {
            return;
        }
        String pgUuid = pgFormatTypeOfColumn(c, "public", "anuncios", "id");
        if (pgUuid != null && isPhysicalPostgresUuid(pgUuid)) {
            try {
                exec(
                    c,
                    "UPDATE public.anuncios SET uuid = id WHERE uuid IS NULL AND id IS NOT NULL"
                );
            } catch (SQLException ignored) {
                // best-effort antes de remover a coluna
            }
        }
        exec(c, "ALTER TABLE public.anuncios DROP COLUMN IF EXISTS uuid CASCADE");
        System.err.println(
            "MIGRAÇÃO: removida coluna obsoleta public.anuncios.uuid (o serviço usa apenas public.anuncios.id)."
        );
    }

    /**
     * Histórico de anúncios entregues (mobile). Se existir tabela antiga com colunas
     * diferentes, recria o esquema actual.
     */
    private static void migrateEntregasIfNeeded(Connection c) throws SQLException {
        if (tableExists(c, "entregas")
            && !columnExists(c, "entregas", "email_destinatario")) {
            exec(c, "DROP TABLE IF EXISTS entregas CASCADE");
            System.err.println(
                "MIGRAÇÃO: tabela entregas antiga removida (esquema incompatível); a recriar."
            );
        }

        if (!tableExists(c, "entregas")) {
            createEntregasTable(c);
            return;
        }

        ensureEntregasColumn(c, "email_destinatario",
            "VARCHAR(320) NOT NULL DEFAULT ''");
        ensureEntregasColumn(c, "anuncio_id", "UUID");
        ensureEntregasColumn(c, "local_name", "TEXT NOT NULL DEFAULT ''");
        ensureEntregasColumn(c, "texto", "TEXT NOT NULL DEFAULT ''");
        ensureEntregasColumn(c, "email_autor", "VARCHAR(320) NOT NULL DEFAULT ''");
        ensureEntregasColumn(c, "entregue_em",
            "TIMESTAMPTZ NOT NULL DEFAULT NOW()");

        try {
            exec(
                c,
                "CREATE INDEX IF NOT EXISTS idx_entregas_destinatario "
                    + "ON entregas(email_destinatario, entregue_em DESC)"
            );
        } catch (SQLException e) {
            if (!"42703".equals(e.getSQLState())) {
                throw e;
            }
            exec(c, "DROP TABLE IF EXISTS entregas CASCADE");
            createEntregasTable(c);
            System.err.println("MIGRAÇÃO: tabela entregas recriada após falha no índice.");
        }

        // Um anúncio só conta uma vez por destinatário (índice único + dedupe na migração)
        dedupeEntregasRows(c);
        exec(
            c,
            "CREATE UNIQUE INDEX IF NOT EXISTS entregas_destinatario_anuncio_uidx "
                + "ON entregas(email_destinatario, anuncio_id)"
        );
    }

    /** Remove linhas duplicadas (mesmo destinatário + anúncio), mantendo a mais recente. */
    private static void dedupeEntregasRows(Connection c) throws SQLException {
        exec(
            c,
            "DELETE FROM entregas a USING entregas b "
                + "WHERE a.email_destinatario = b.email_destinatario "
                + "AND a.anuncio_id = b.anuncio_id "
                + "AND a.id < b.id"
        );
    }

    private static void migrateChatIfNeeded(Connection c) throws SQLException {
        if (!tableExists(c, "mensagens_chat")) {
            exec(
                c,
                "CREATE TABLE mensagens_chat ("
                    + "id BIGSERIAL PRIMARY KEY, "
                    + "remetente_email VARCHAR(320) NOT NULL REFERENCES utilizadores(email) ON DELETE CASCADE, "
                    + "destinatario_email VARCHAR(320) NOT NULL REFERENCES utilizadores(email) ON DELETE CASCADE, "
                    + "texto TEXT NOT NULL, "
                    + "enviada_em TIMESTAMPTZ NOT NULL DEFAULT NOW())"
            );
        }
        exec(
            c,
            "CREATE INDEX IF NOT EXISTS idx_chat_conversa "
                + "ON mensagens_chat(remetente_email, destinatario_email, enviada_em)"
        );
    }

    private static void createEntregasTable(Connection c) throws SQLException {
        exec(
            c,
            "CREATE TABLE entregas ("
                + "id BIGSERIAL PRIMARY KEY, "
                + "email_destinatario VARCHAR(320) NOT NULL REFERENCES utilizadores(email) ON DELETE CASCADE, "
                + "anuncio_id UUID NOT NULL REFERENCES anuncios(id) ON DELETE CASCADE, "
                + "local_name TEXT NOT NULL, "
                + "texto TEXT NOT NULL, "
                + "email_autor VARCHAR(320) NOT NULL, "
                + "entregue_em TIMESTAMPTZ NOT NULL DEFAULT NOW())"
        );
        exec(
            c,
            "CREATE INDEX IF NOT EXISTS idx_entregas_destinatario "
                + "ON entregas(email_destinatario, entregue_em DESC)"
        );
        exec(
            c,
            "CREATE UNIQUE INDEX IF NOT EXISTS entregas_destinatario_anuncio_uidx "
                + "ON entregas(email_destinatario, anuncio_id)"
        );
    }

    private static void ensureEntregasColumn(Connection c, String column, String ddl)
        throws SQLException {
        if (!columnExists(c, "entregas", column)) {
            exec(c, "ALTER TABLE entregas ADD COLUMN " + column + " " + ddl);
        }
    }

    private static void migrateDashboardMetricsIfNeeded(Connection c) throws SQLException {
        if (!tableExists(c, "dashboard_metricas")) {
            exec(
                c,
                "CREATE TABLE IF NOT EXISTS dashboard_metricas ("
                    + "chave VARCHAR(64) PRIMARY KEY, valor BIGINT NOT NULL DEFAULT 0)"
            );
        }
        exec(
            c,
            "INSERT INTO dashboard_metricas (chave, valor) VALUES ('entregas', 0) "
                + "ON CONFLICT (chave) DO NOTHING"
        );
    }

    private static void createIndexesIfPossible(Connection c) throws Exception {
        if (!tableExists(c, "anuncios")) {
            return;
        }
        if (!columnExists(c, "anuncios", "local_name")) {
            return;
        }
        exec(c, "CREATE INDEX IF NOT EXISTS idx_anuncios_local ON anuncios(local_name)");
    }

    private static boolean tableExists(Connection c, String table) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(
            "SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = ?")) {
            ps.setString(1, table);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    private static boolean columnExists(Connection c, String table, String column) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(
            "SELECT 1 FROM information_schema.columns "
                + "WHERE table_schema='public' AND table_name=? AND column_name=?")) {
            ps.setString(1, table);
            ps.setString(2, column);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    /**
     * Garante que {@code anuncios.id} é {@code uuid}. Converte texto quando possível; caso contrário recria a coluna.
     */
    private static void ensureAnunciosIdIsUuidCompatible(Connection c) throws Exception {
        if (!columnExists(c, "anuncios", "id")) {
            return;
        }
        String pgType = pgFormatTypeOfColumn(c, "public", "anuncios", "id");
        if (pgType != null && isPhysicalPostgresUuid(pgType)) {
            return;
        }
        String infoSchemaType = columnDataType(c, "anuncios", "id");
        if (pgType == null && infoSchemaType != null && "uuid".equalsIgnoreCase(infoSchemaType.trim())) {
            return;
        }
        // Texto → tenta casting; falhas (texto não-UUID) → recria coluna
        String t = pgType == null ? "" : pgType.toLowerCase(Locale.ROOT);
        boolean textLike =
            t.contains("character varying")
                || t.contains("varchar")
                || t.contains("character(")
                || t.equals("text")
                || t.startsWith("text ")
                || (infoSchemaType != null && infoSchemaType.contains("character"));
        if (textLike) {
            try {
                exec(c, "ALTER TABLE public.anuncios ALTER COLUMN id TYPE UUID USING trim(id::text)::uuid");
                return;
            } catch (SQLException e) {
                // continua para recriar id
            }
        }
        replaceAnunciosIdColumnWithUuid(c);
    }

    private static boolean isPhysicalPostgresUuid(String formatType) {
        if (formatType == null) {
            return false;
        }
        String s = formatType.toLowerCase(Locale.ROOT).trim();
        return "uuid".equals(s) || s.startsWith("uuid ");
    }

    /** Tipo físico da coluna (ex.: {@code integer}, {@code bigint}, {@code uuid}, {@code character varying}). */
    private static String pgFormatTypeOfColumn(Connection c, String schema, String table, String column)
        throws SQLException {
        try (
            PreparedStatement ps = c.prepareStatement(
                "SELECT pg_catalog.format_type(a.atttypid, a.atttypmod) "
                    + "FROM pg_catalog.pg_attribute a "
                    + "JOIN pg_catalog.pg_class cls ON cls.oid = a.attrelid "
                    + "JOIN pg_catalog.pg_namespace nsp ON nsp.oid = cls.relnamespace "
                    + "WHERE nsp.nspname = ? AND cls.relkind = 'r' AND cls.relname = ? "
                    + "AND a.attname = ? AND a.attnum > 0 AND NOT a.attisdropped"
            )) {
            ps.setString(1, schema);
            ps.setString(2, table);
            ps.setString(3, column);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getString(1) : null;
            }
        }
    }

    /**
     * Substitui a coluna id por UUID — necessário para {@link AnunciosLocRepository#insertAd}.
     */
    private static void replaceAnunciosIdColumnWithUuid(Connection c) throws Exception {
        ensureGenRandomUuidFunction(c);

        boolean prev = c.getAutoCommit();
        c.setAutoCommit(false);
        try {
            exec(c, "ALTER TABLE public.anuncios DROP COLUMN IF EXISTS id CASCADE");
            exec(
                c,
                "ALTER TABLE public.anuncios ADD COLUMN id UUID NOT NULL "
                    + "DEFAULT gen_random_uuid()"
            );
            exec(c, "ALTER TABLE ONLY public.anuncios ADD CONSTRAINT anuncios_pkey PRIMARY KEY (id)");
            c.commit();
            System.err.println(
                "MIGRAÇÃO: coluna public.anuncios.id recriada como UUID (valor antigo eram outros tipos)."
            );
        } catch (Exception e) {
            try {
                c.rollback();
            } catch (SQLException ignored) {
                // best-effort
            }
            throw e;
        } finally {
            c.setAutoCommit(prev);
        }
    }

    private static void ensureGenRandomUuidFunction(Connection c) throws SQLException {
        Boolean hasCore = executeExists(
            c,
            "SELECT EXISTS (SELECT 1 FROM pg_catalog.pg_proc "
                + "WHERE proname='gen_random_uuid' AND pronamespace=("
                + " SELECT oid FROM pg_catalog.pg_namespace WHERE nspname='pg_catalog'))"
        );
        if (Boolean.TRUE.equals(hasCore)) {
            return;
        }
        try {
            exec(c, "CREATE EXTENSION IF NOT EXISTS pgcrypto");
        } catch (SQLException ignored) {
            // Sem permissões para criar extension — continuamos e deixamos o ALTER falhar com mensagem clara
        }
    }

    private static Boolean executeExists(Connection c, String sql) throws SQLException {
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            return rs.next() ? rs.getBoolean(1) : null;
        }
    }

    private static String columnDataType(Connection c, String table, String column) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(
            "SELECT data_type FROM information_schema.columns "
                + "WHERE table_schema='public' AND table_name=? AND column_name=?")) {
            ps.setString(1, table);
            ps.setString(2, column);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getString(1) : null;
            }
        }
    }

    private static void exec(Connection c, String sql) throws SQLException {
        try (Statement st = c.createStatement()) {
            st.execute(sql);
        }
    }

    private static java.util.List<String> splitSqlStatements(String sql) {
        java.util.ArrayList<String> out = new java.util.ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String rawLine : sql.split("\\R")) {
            String line = rawLine.trim();
            if (line.isEmpty() || line.startsWith("--")) {
                continue;
            }
            cur.append(line).append('\n');
            if (line.endsWith(";")) {
                String s = cur.toString().trim();
                if (!s.isEmpty()) {
                    out.add(s);
                }
                cur.setLength(0);
            }
        }
        String tail = cur.toString().trim();
        if (!tail.isEmpty()) {
            out.add(tail);
        }
        return out;
    }

    private static String firstNonBlank(String a, String b) {
        if (a != null && !a.trim().isEmpty()) {
            return a.trim();
        }
        return b;
    }
}
