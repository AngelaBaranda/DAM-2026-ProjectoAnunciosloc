package pt.uan.anunciosloc.server;

import javax.jws.WebMethod;
import javax.jws.WebService;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import pt.uan.anunciosloc.infrastructure.UDDIHelper;

@WebService(
    name = "AnunciosLoc",
    targetNamespace = "http://server.anunciosloc.uan.pt/",
    serviceName = "AnunciosLocService"
)
public class AnunciosLocEndpoint {

    private final AnunciosLocRepository db = new AnunciosLocRepository();

    // Cache em memória (sincronizada com PostgreSQL)
    private final Map<String, Utilizador> utilizadores = new HashMap<>();
    private final Map<String, List<Anuncio>> anunciosPorLocal = new HashMap<>();
    private final Map<String, String> sessoesPorToken = new HashMap<>();

    // Bónus (mantém o comportamento “de negócio” anterior)
    private static final int BONUS_POSTAR = 5;
    private static final int BONUS_ENTREGA = 2;

    public AnunciosLocEndpoint() {
        reloadCaches();
    }

    private synchronized void reloadCaches() {
        try {
            utilizadores.clear();
            utilizadores.putAll(db.loadAllUsers());

            anunciosPorLocal.clear();
            anunciosPorLocal.putAll(db.loadAllAdsGroupedByLocal());
        } catch (Exception e) {
            throw new RuntimeException("Falha ao carregar dados do PostgreSQL: " + e.getMessage(), e);
        }
    }

    // -------------------------------------------------------
    // Operações principais
    // -------------------------------------------------------

    @WebMethod
    public synchronized String ativarUtilizador(String email) {
        try {
            if (!email.matches("[a-zA-Z0-9.]+@[a-zA-Z0-9.]+")) {
                return "ERRO: email inválido — " + email;
            }
            if (db.userExists(email)) {
                return "ERRO: utilizador já existe — " + email;
            }

            Utilizador u = new Utilizador(email);
            db.insertUser(u.getEmail(), u.getSaldo(), u.getUltimoAnuncio());
            utilizadores.put(email, u);
            return "OK: utilizador activado — " + email + " (saldo inicial: 10 pontos)";
        } catch (Exception e) {
            return "ERRO: falha na base de dados — " + e.getMessage();
        }
    }

    @WebMethod
    public synchronized String registarUtilizador(String email, String nome, String senha) {
        try {
            if (nome == null || nome.trim().isEmpty()) {
                return "ERRO: nome inválido";
            }
            if (senha == null || senha.length() < 6) {
                return "ERRO: senha deve ter pelo menos 6 caracteres";
            }
            if (!email.matches("[a-zA-Z0-9.]+@[a-zA-Z0-9.]+")) {
                return "ERRO: email inválido — " + email;
            }
            if (db.userExists(email)) {
                return "ERRO: utilizador já existe — " + email;
            }

            Utilizador u = new Utilizador(email);
            db.insertUserWithAuth(email, nome.trim(), senha, u.getSaldo(), u.getUltimoAnuncio());
            utilizadores.put(email, u);
            return "OK: utilizador registado — " + email;
        } catch (Exception e) {
            return "ERRO: falha na base de dados — " + e.getMessage();
        }
    }

    @WebMethod
    public synchronized String login(String email, String senha) {
        try {
            AnunciosLocRepository.UserAuth auth = db.loadUserAuth(email);
            if (auth == null) {
                return "ERRO: utilizador não encontrado";
            }
            if (auth.senha == null || auth.senha.isEmpty()) {
                return "ERRO: conta sem credenciais de login. Use registarUtilizador.";
            }
            if (!auth.senha.equals(senha)) {
                return "ERRO: senha inválida";
            }

            String token = UUID.randomUUID().toString();
            String nome = (auth.nome == null || auth.nome.isBlank()) ? email : auth.nome;
            sessoesPorToken.put(token, email);
            return "OK|" + token + "|" + nome + "|" + auth.saldo;
        } catch (Exception e) {
            return "ERRO: falha na base de dados — " + e.getMessage();
        }
    }

    @WebMethod
    public synchronized String logout(String token) {
        if (token == null || token.isBlank()) {
            return "ERRO: token inválido";
        }
        String removed = sessoesPorToken.remove(token);
        if (removed == null) {
            return "ERRO: sessão não encontrada";
        }
        return "OK: sessão terminada";
    }

    /**
     * Alias usado por alguns clientes mobile (mesma lógica que {@link #postarMensagem}).
     */
    @WebMethod
    public synchronized String publicarAnuncio(String email, String localName, String texto) {
        return postarMensagem(email, localName, texto);
    }

    /**
     * Publicar usando token de sessão do {@link #login} (útil se a app não enviar o email).
     */
    @WebMethod
    public synchronized String postarMensagemComToken(String token, String localName, String texto) {
        if (token == null || token.isBlank()) {
            return "ERRO: token inválido";
        }
        String email = sessoesPorToken.get(token.trim());
        if (email == null) {
            return "ERRO: sessão expirada — faz login outra vez";
        }
        return postarMensagem(email, localName, texto);
    }

    @WebMethod
    public synchronized String postarMensagem(String email, String localName, String texto) {
        System.out.println("postarMensagem: email=" + email + " local=" + localName);
        try {
            if (localName == null || localName.isBlank()) {
                return "ERRO: indica o local do anúncio";
            }
            if (texto == null || texto.isBlank()) {
                return "ERRO: indica o texto do anúncio";
            }

            String emailResolvido = resolverEmailUtilizador(email);
            if (emailResolvido == null) {
                return "ERRO: utilizador não identificado — usa o email da conta (não só o nome '"
                    + email + "') ou faz login na app";
            }

            String err = garantirUtilizadorNaBase(emailResolvido);
            if (err != null) {
                return err;
            }

            String local = localName.trim();
            String corpo = texto.trim();
            Anuncio anuncio = db.insertAd(emailResolvido, local, corpo);

            anunciosPorLocal
                .computeIfAbsent(local, k -> new ArrayList<>())
                .add(anuncio);

            Utilizador u = utilizadores.get(emailResolvido);
            if (u != null) {
                u.atualizarUltimoAnuncio();
                db.updateUserLastPost(emailResolvido, u.getUltimoAnuncio());
            } else {
                Utilizador loaded = db.loadUser(emailResolvido);
                if (loaded != null) {
                    loaded.atualizarUltimoAnuncio();
                    utilizadores.put(emailResolvido, loaded);
                    db.updateUserLastPost(emailResolvido, loaded.getUltimoAnuncio());
                }
            }

            db.addSaldo(emailResolvido, BONUS_POSTAR);
            Utilizador cached = utilizadores.get(emailResolvido);
            if (cached != null) {
                cached.adicionarSaldo(BONUS_POSTAR);
            }

            String ok = "OK: anúncio publicado em '" + local + "' — id: " + anuncio.getId();
            System.out.println("postarMensagem OK: " + ok);
            return ok;
        } catch (Exception e) {
            System.err.println("postarMensagem ERRO: " + e.getMessage());
            e.printStackTrace();
            return "ERRO: falha na base de dados — " + e.getMessage();
        }
    }

    @WebMethod
    public synchronized String receberMensagem(String email, String localName) {
        try {
            String emailResolvido = resolverEmailUtilizador(email);
            if (emailResolvido == null) {
                return "ERRO: utilizador não identificado — " + email;
            }
            String err = garantirUtilizadorNaBase(emailResolvido);
            if (err != null) {
                return err;
            }
            if (localName == null || localName.isBlank()) {
                return "ERRO: indica o local";
            }

            List<Anuncio> anuncios = db.listAdsByLocal(localName.trim());
            if (anuncios.isEmpty()) {
                return "Sem anúncios em '" + localName + "'";
            }

            StringBuilder sb = new StringBuilder();
            sb.append("Anúncios em '").append(localName).append("':\n");

            for (Anuncio a : anuncios) {
                sb.append("  - ").append(a.toString()).append("\n");
                if (db.recordEntrega(emailResolvido, a)) {
                    Utilizador autor = utilizadores.get(a.getEmailAutor());
                    if (autor != null) {
                        autor.adicionarSaldo(BONUS_ENTREGA);
                    }
                    db.addSaldo(a.getEmailAutor(), BONUS_ENTREGA);
                }
            }

            db.syncMetricEntregasUtilizador(emailResolvido);
            db.syncMetricEntregasGlobal();
            reloadCaches();
            return sb.toString();
        } catch (Exception e) {
            return "ERRO: falha na base de dados — " + e.getMessage();
        }
    }

    /** Nome visível na app (ex. terezangela) → email na BD; ou email directo. */
    private String resolverEmailUtilizador(String emailOuNome) throws Exception {
        if (emailOuNome == null || emailOuNome.isBlank()) {
            return null;
        }
        String s = emailOuNome.trim();
        if (s.contains("@") && s.indexOf('@') > 0 && s.indexOf('@') < s.length() - 1) {
            return s;
        }
        return db.findEmailByNome(s);
    }

    /** Cria utilizador na BD se só existir no Kerberos / app mobile. */
    private String garantirUtilizadorNaBase(String email) throws Exception {
        if (db.userExists(email)) {
            return null;
        }
        if (!email.matches("[a-zA-Z0-9.]+@[a-zA-Z0-9.]+")) {
            return "ERRO: email inválido — " + email;
        }
        Utilizador u = new Utilizador(email);
        db.insertUser(email, u.getSaldo(), u.getUltimoAnuncio());
        utilizadores.put(email, u);
        System.out.println("Utilizador criado automaticamente na BD (mobile/Kerberos): " + email);
        return null;
    }

    /**
     * Lista todos os anúncios já entregues ao utilizador (histórico persistido na BD).
     */
    @WebMethod
    public synchronized String listarAnunciosEntregues(String email) {
        try {
            String emailResolvido = resolverEmailUtilizador(email);
            if (emailResolvido == null) {
                return "ERRO: utilizador não identificado — " + email;
            }
            String err = garantirUtilizadorNaBase(emailResolvido);
            if (err != null) {
                return err;
            }

            db.reconcileEntregasMetric(emailResolvido);

            List<AnunciosLocRepository.EntregaRegisto> entregas = db.listEntregasForUser(emailResolvido);
            if (entregas.isEmpty()) {
                return "Ainda não tens entregas.\n\n"
                    + "Usa «Ver anúncios» acima quando estiveres num local com anúncios.";
            }

            DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm", Locale.ROOT)
                .withZone(ZoneId.systemDefault());

            StringBuilder sb = new StringBuilder();
            sb.append("Anúncios entregues (").append(entregas.size()).append("):\n\n");
            int i = 1;
            for (AnunciosLocRepository.EntregaRegisto e : entregas) {
                sb.append("📍 ").append(e.localName).append("\n");
                sb.append("   ").append(e.emailAutor).append("\n");
                sb.append("   \"").append(e.texto).append("\"\n");
                sb.append("   Recebido: ")
                    .append(fmt.format(Instant.ofEpochMilli(e.entregueEmMs)))
                    .append("\n\n");
            }
            return sb.toString().trim();
        } catch (Exception e) {
            return "ERRO: falha na base de dados — " + e.getMessage();
        }
    }

    @WebMethod
    public synchronized int consultarSaldo(String email) {
        try {
            return db.getSaldo(email);
        } catch (Exception e) {
            return -1;
        }
    }

    @WebMethod
    public String listarInfraestruturas(double lat, double lon, int k) {
        try {
            return InfrastructureCatalogClient.listarOrdenadoPorDistancia(lat, lon, k);
        } catch (Exception e) {
            return "ERRO: " + e.getMessage();
        }
    }

    /**
     * Publica anúncio na infraestrutura onde o utilizador se encontra (GPS dentro do raio).
     */
    @WebMethod
    public synchronized String publicarAnuncioPorGps(String email, double lat, double lon, String texto) {
        InfrastructureCatalogClient.InfraGeo infra =
            InfrastructureCatalogClient.resolveNaPosicao(lat, lon);
        if (infra == null) {
            return "ERRO: não estás dentro de nenhuma infraestrutura registada. "
                + "Regista uma no separador Locais ou aproxima-te de uma existente (raio GPS).";
        }
        InfrastructureCatalogClient.encaminharParaInfra(infra.url, email, texto);
        String r = postarMensagem(email, infra.nome, texto);
        if (r != null && r.startsWith("OK")) {
            return r + " — infraestrutura: " + infra.nome;
        }
        return r;
    }

    @WebMethod
    public synchronized String publicarAnuncioPorGpsComToken(String token, double lat, double lon, String texto) {
        if (token == null || token.isBlank()) {
            return "ERRO: token inválido";
        }
        String email = sessoesPorToken.get(token.trim());
        if (email == null) {
            return "ERRO: sessão expirada — faz login outra vez";
        }
        return publicarAnuncioPorGps(email, lat, lon, texto);
    }

    /**
     * Recebe anúncios da infraestrutura onde o utilizador se encontra (mesmo local GPS).
     */
    @WebMethod
    public synchronized String receberMensagemPorGps(String email, double lat, double lon) {
        InfrastructureCatalogClient.InfraGeo infra =
            InfrastructureCatalogClient.resolveNaPosicao(lat, lon);
        if (infra == null) {
            return "ERRO: não estás dentro de nenhuma infraestrutura registada. "
                + "Regista uma no separador Locais ou aproxima-te de uma existente (raio GPS).";
        }
        String r = receberMensagem(email, infra.nome);
        if (r != null && !r.startsWith("ERRO")) {
            return r + "\n[Infra detectada: " + infra.nome + "]";
        }
        return r;
    }

    /**
     * Regista infraestrutura (app mobile). jUDDI em localhost:9090 é opcional; usa registo local se estiver parado.
     */
    @WebMethod
    public synchronized String registarInfraestrutura(String nome, double lat, double lon) {
        return UDDIHelper.registarInfraestruturaCatalog(nome, lat, lon);
    }

    /**
     * Resumo para o painel web: utilizadores|anúncios|infraestruturas (UDDI/local)|entregas (persistido).
     */
    @WebMethod
    public synchronized String obterResumoDashboard() {
        try {
            int users = db.countUsers();
            int ads = db.countAds();
            int infras = 0;
            try {
                infras = new LinkedHashSet<>(UDDIHelper.pesquisar("Infrastructure")).size();
            } catch (Exception ignored) {
                infras = 0;
            }
            long entregas = db.getMetric("entregas");
            return users + "|" + ads + "|" + infras + "|" + entregas;
        } catch (Exception e) {
            return "ERRO|" + e.getMessage();
        }
    }

    /**
     * Mantém a sessão após refresh da página (token guardado no browser).
     */
    @WebMethod
    public synchronized String validarSessao(String token) {
        if (token == null || token.isBlank()) {
            return "ERRO: token vazio";
        }
        String email = sessoesPorToken.get(token);
        if (email == null) {
            return "ERRO: sessão expirada ou servidor reiniciado — volta a entrar";
        }
        try {
            AnunciosLocRepository.UserAuth auth = db.loadUserAuth(email);
            if (auth == null) {
                sessoesPorToken.remove(token);
                return "ERRO: utilizador já não existe";
            }
            String nome = (auth.nome == null || auth.nome.isBlank()) ? email : auth.nome;
            return "OK|" + nome + "|" + auth.saldo + "|" + email;
        } catch (Exception e) {
            return "ERRO: " + e.getMessage();
        }
    }

    @WebMethod
    public String obterInfoInfraestrutura(String nomInfra) {
        if (nomInfra == null || nomInfra.isBlank()) {
            return "ERRO: indica o nome (ou parte) da infraestrutura, ou o URL do serviço.";
        }
        try {
            return InfrastructureCatalogClient.obterInfoPorNomeOuUrl(nomInfra.trim());
        } catch (Exception e) {
            return "ERRO: " + e.getMessage();
        }
    }

    // -------------------------------------------------------
    // Operações auxiliares (para testes)
    // -------------------------------------------------------

    @WebMethod
    public synchronized String ping() {
        try {
            return "AnunciosLoc activo (PostgreSQL). Utilizadores: " + db.countUsers()
                 + " | Locais com anúncios: " + db.countDistinctLocalsWithAds();
        } catch (Exception e) {
            return "AnunciosLoc activo mas BD inacessível: " + e.getMessage();
        }
    }

    @WebMethod
    public synchronized void clear() {
        try {
            db.clearAll();
            reloadCaches();
        } catch (Exception e) {
            throw new RuntimeException("Falha ao limpar PostgreSQL: " + e.getMessage(), e);
        }
    }

    // -------------------------------------------------------
    // Operações para cliente mobile (SOAP)
    // -------------------------------------------------------

    @WebMethod
    public synchronized String listarAnuncios(String localName) {
        return listarAnunciosPorLocal(localName);
    }

    /** Lista anúncios de um local (sem exigir entrega/bónus). */
    @WebMethod
    public synchronized String listarAnunciosPorLocal(String localName) {
        if (localName == null || localName.isBlank()) {
            return "ERRO: indica o nome do local";
        }
        try {
            List<Anuncio> anuncios = db.listAdsByLocal(localName.trim());
            if (anuncios.isEmpty()) {
                return "Sem anúncios em '" + localName.trim() + "'";
            }
            StringBuilder sb = new StringBuilder();
            sb.append("Anúncios em '").append(localName.trim()).append("':\n");
            for (Anuncio a : anuncios) {
                sb.append("  - ").append(a.toString()).append("\n");
            }
            return sb.toString();
        } catch (Exception e) {
            return "ERRO: falha na base de dados — " + e.getMessage();
        }
    }

    /** Locais que têm pelo menos um anúncio (um por linha). */
    @WebMethod
    public synchronized String listarLocaisComAnuncios() {
        try {
            List<String> locais = db.listDistinctLocals();
            if (locais.isEmpty()) {
                return "Sem locais com anúncios";
            }
            return String.join("\n", locais);
        } catch (Exception e) {
            return "ERRO: falha na base de dados — " + e.getMessage();
        }
    }

    @WebMethod
    public synchronized int contarAnunciosUtilizador(String emailOuNome) {
        if (emailOuNome == null || emailOuNome.isBlank()) {
            return 0;
        }
        try {
            String email = resolverEmailUtilizador(emailOuNome);
            if (email == null) {
                return 0;
            }
            return db.countAdsByAuthor(email);
        } catch (Exception e) {
            return 0;
        }
    }

    @WebMethod
    public synchronized int contarEntregasUtilizador(String emailOuNome) {
        if (emailOuNome == null || emailOuNome.isBlank()) {
            return 0;
        }
        try {
            String email = resolverEmailUtilizador(emailOuNome);
            if (email == null) {
                return 0;
            }
            db.reconcileEntregasMetric(email);
            return (int) Math.min(Integer.MAX_VALUE, db.countEntregasForUser(email));
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * Envia mensagem privada entre dois utilizadores (chat).
     */
    @WebMethod
    public synchronized String enviarMensagemChat(String remetente, String destinatario, String texto) {
        try {
            String from = resolverEmailUtilizador(remetente);
            String to = resolverEmailUtilizador(destinatario);
            if (from == null || from.isBlank()) {
                return "ERRO: remetente não identificado";
            }
            if (to == null || to.isBlank()) {
                return "ERRO: destinatário não identificado";
            }
            if (from.equalsIgnoreCase(to)) {
                return "ERRO: não podes enviar mensagem a ti próprio";
            }
            if (texto == null || texto.isBlank()) {
                return "ERRO: mensagem vazia";
            }
            String errFrom = garantirUtilizadorNaBase(from);
            if (errFrom != null) {
                return errFrom;
            }
            String errTo = garantirUtilizadorNaBase(to);
            if (errTo != null) {
                return errTo;
            }
            db.insertChatMessage(from, to, texto.trim());
            return "OK: mensagem enviada";
        } catch (Exception e) {
            return "ERRO: falha na base de dados — " + e.getMessage();
        }
    }

    /**
     * Lista mensagens entre o utilizador autenticado (email) e um contacto.
     * Formato: CHAT|N linhas remetente|texto|timestampMs
     */
    @WebMethod
    public synchronized String listarMensagensChat(String emailUtilizador, String emailContacto) {
        try {
            String eu = resolverEmailUtilizador(emailUtilizador);
            String contacto = resolverEmailUtilizador(emailContacto);
            if (eu == null || eu.isBlank()) {
                return "ERRO: utilizador não identificado";
            }
            if (contacto == null || contacto.isBlank()) {
                return "ERRO: contacto não identificado";
            }
            String err = garantirUtilizadorNaBase(eu);
            if (err != null) {
                return err;
            }
            garantirUtilizadorNaBase(contacto);

            List<AnunciosLocRepository.ChatMensagem> msgs = db.listChatMessages(eu, contacto);
            if (msgs.isEmpty()) {
                return "CHAT|0\nAinda não há mensagens. Envia a primeira!";
            }
            StringBuilder sb = new StringBuilder();
            sb.append("CHAT|").append(msgs.size()).append('\n');
            for (AnunciosLocRepository.ChatMensagem m : msgs) {
                sb.append(m.remetente).append('|')
                    .append(escapeChatField(m.texto)).append('|')
                    .append(m.enviadaEmMs).append('\n');
            }
            return sb.toString().trim();
        } catch (Exception e) {
            return "ERRO: falha na base de dados — " + e.getMessage();
        }
    }

    private static String escapeChatField(String s) {
        if (s == null) {
            return "";
        }
        return s.replace("|", "/").replace("\n", " ").replace("\r", " ");
    }

    /**
     * Polling para notificações mobile.
     * @param entregasConhecidas total de entregas que a app já viu
     * @param ultimoChatMs timestamp ms da última mensagem de chat já notificada
     * @return NENHUMA | ANUNCIO|count|local|autor|texto | CHAT|remetente|texto|ts
     */
    @WebMethod
    public synchronized String verificarNovidades(String email, int entregasConhecidas, long ultimoChatMs) {
        try {
            String eu = resolverEmailUtilizador(email);
            if (eu == null || eu.isBlank()) {
                return "ERRO: utilizador não identificado";
            }
            String err = garantirUtilizadorNaBase(eu);
            if (err != null) {
                return err;
            }

            int count = db.countEntregasForUser(eu);
            if (count > entregasConhecidas) {
                AnunciosLocRepository.EntregaRegisto ultima = db.latestEntregaForUser(eu);
                if (ultima != null) {
                    return "ANUNCIO|" + count + "|"
                        + escapeChatField(ultima.localName) + "|"
                        + escapeChatField(ultima.emailAutor) + "|"
                        + escapeChatField(ultima.texto);
                }
                return "ANUNCIO|" + count + "|||";
            }

            AnunciosLocRepository.ChatMensagem msg = db.latestIncomingChatAfter(eu, ultimoChatMs);
            if (msg != null) {
                return "CHAT|" + escapeChatField(msg.remetente) + "|"
                    + escapeChatField(msg.texto) + "|" + msg.enviadaEmMs;
            }
            return "NENHUMA";
        } catch (Exception e) {
            return "ERRO: " + e.getMessage();
        }
    }
}

