package pt.uan.anunciosloc.client;

/**
 * Cliente de linha de comandos para testar o AnunciosLoc com o servidor em execução.
 * <p>
 * Exemplos (PowerShell, na pasta {@code anunciosloc-ws}):
 * <pre>
 * mvn -q compile exec:java -Dexec.mainClass=pt.uan.anunciosloc.client.AnunciosLocConsole -Dexec.args="ping"
 * mvn -q compile exec:java -Dexec.mainClass=pt.uan.anunciosloc.client.AnunciosLocConsole "-Dexec.args=ativar alice@uan.ao"
 * mvn -q compile exec:java -Dexec.mainClass=pt.uan.anunciosloc.client.AnunciosLocConsole "-Dexec.args=saldo alice@uan.ao"
 * </pre>
 */
public final class AnunciosLocConsole {

    public static void main(String[] args) throws Exception {
        String wsdl = System.getProperty("anunciosloc.wsdl", AnunciosLocServiceClient.DEFAULT_WSDL);

        if (args.length == 0 || "help".equalsIgnoreCase(args[0])) {
            printHelp(wsdl);
            return;
        }

        AnunciosLocServiceClient client = new AnunciosLocServiceClient(wsdl);
        String cmd = args[0].toLowerCase();

        switch (cmd) {
            case "ping":
                System.out.println(client.ping());
                break;
            case "ativar":
                if (args.length < 2) {
                    System.err.println("Uso: ativar <email>");
                    System.exit(1);
                }
                System.out.println(client.ativarUtilizador(args[1]));
                break;
            case "saldo":
                if (args.length < 2) {
                    System.err.println("Uso: saldo <email>");
                    System.exit(1);
                }
                int s = client.consultarSaldo(args[1]);
                System.out.println(s < 0 ? "Utilizador não encontrado (ou erro)." : "Saldo: " + s);
                break;
            case "postar":
                if (args.length < 4) {
                    System.err.println("Uso: postar <email> <local> <texto...>");
                    System.exit(1);
                }
                String texto = joinArgs(args, 3);
                System.out.println(client.postarMensagem(args[1], args[2], texto));
                break;
            case "receber":
                if (args.length < 3) {
                    System.err.println("Uso: receber <email> <local>");
                    System.exit(1);
                }
                System.out.println(client.receberMensagem(args[1], args[2]));
                break;
            case "limpar":
                client.clear();
                System.out.println("Estado do servidor limpo (apenas em memória).");
                break;
            default:
                System.err.println("Comando desconhecido: " + args[0]);
                printHelp(wsdl);
                System.exit(1);
        }
    }

    private static void printHelp(String wsdl) {
        System.out.println("Cliente AnunciosLoc — WSDL: " + wsdl);
        System.out.println();
        System.out.println("Comandos:");
        System.out.println("  ping");
        System.out.println("  ativar <email>");
        System.out.println("  saldo <email>");
        System.out.println("  postar <email> <local> <texto com espaços permitido>");
        System.out.println("  receber <email> <local>");
        System.out.println("  limpar   (chama clear() no servidor)");
        System.out.println("  help");
        System.out.println();
        System.out.println("Outro WSDL: -Danunciosloc.wsdl=http://host:porta/caminho?wsdl");
    }

    private static String joinArgs(String[] args, int from) {
        StringBuilder sb = new StringBuilder();
        for (int i = from; i < args.length; i++) {
            if (i > from) {
                sb.append(' ');
            }
            sb.append(args[i]);
        }
        return sb.toString();
    }
}
