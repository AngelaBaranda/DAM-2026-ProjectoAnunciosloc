package pt.uan.anunciosloc.client;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import java.net.URL;

/**
 * Cliente JAX-WS para o serviço AnunciosLoc (usa o WSDL publicado pelo servidor).
 */
public class AnunciosLocServiceClient {

    public static final String DEFAULT_WSDL = "http://localhost:8080/anunciosloc?wsdl";
    private static final String NAMESPACE = "http://server.anunciosloc.uan.pt/";
    private static final String SERVICE_NAME = "AnunciosLocService";

    private final AnunciosLocPortType port;

    public AnunciosLocServiceClient() throws Exception {
        this(DEFAULT_WSDL);
    }

    public AnunciosLocServiceClient(String wsdlUrl) throws Exception {
        URL url = new URL(wsdlUrl);
        QName qName = new QName(NAMESPACE, SERVICE_NAME);
        Service service = Service.create(url, qName);
        this.port = service.getPort(AnunciosLocPortType.class);
    }

    public AnunciosLocPortType getPort() {
        return port;
    }

    public String ativarUtilizador(String email) {
        return port.ativarUtilizador(email);
    }

    public String postarMensagem(String email, String local, String texto) {
        return port.postarMensagem(email, local, texto);
    }

    public String receberMensagem(String email, String local) {
        return port.receberMensagem(email, local);
    }

    public int consultarSaldo(String email) {
        return port.consultarSaldo(email);
    }

    public String ping() {
        return port.ping();
    }

    public void clear() {
        port.clear();
    }
}
