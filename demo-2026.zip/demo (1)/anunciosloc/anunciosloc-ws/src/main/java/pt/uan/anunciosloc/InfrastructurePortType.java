package pt.uan.anunciosloc;

import javax.jws.WebMethod;
import javax.jws.WebService;

/**
 * Contrato mínimo do serviço de infraestrutura usado pelo QuorumManager.
 */
@WebService(
    name = "Infrastructure",
    targetNamespace = "http://infrastructure.anunciosloc.uan.pt/"
)
public interface InfrastructurePortType {

    @WebMethod
    int[] lerSaldo(String email);

    @WebMethod
    String escreverSaldo(String email, int novoSaldo, int seq);
}
