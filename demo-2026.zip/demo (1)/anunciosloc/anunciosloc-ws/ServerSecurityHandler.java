package pt.uan.anunciosloc.server;

import jakarta.xml.ws.handler.MessageContext;
import jakarta.xml.ws.handler.soap.*;
import javax.crypto.SecretKey;
import javax.xml.namespace.QName;
import java.util.*;

public class ServerSecurityHandler implements SOAPHandler<SOAPMessageContext> {

    private static final String SENHA_ANUNCIOSLOC = "anunciosloc-secret-2025";

    // Sessões activas: email -> chave de sessão
    private static Map<String, SecretKey> sessoes = new HashMap<>();

    @Override
    public boolean handleMessage(SOAPMessageContext ctx) {
        boolean isInbound = !(Boolean) ctx.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);

        if (isInbound) {
            try {
                var envelope = ctx.getMessage().getSOAPPart().getEnvelope();
                var header   = envelope.getHeader();

                if (header == null) {
                    throw new SecurityException("Pedido sem cabeçalho de segurança");
                }

                // Extrai ticket, autenticador e MAC
                String ticket       = getHeaderValue(header, "ticket");
                String autenticador = getHeaderValue(header, "autenticador");
                String mac          = getHeaderValue(header, "mac");

                if (ticket == null || autenticador == null || mac == null) {
                    throw new SecurityException("Cabeçalhos de segurança incompletos");
                }

                // Decifra o ticket com a chave do AnunciosLoc
                SecretKey chaveServidor = CryptoHelper.derivarChave(SENHA_ANUNCIOSLOC);
                String conteudo = CryptoHelper.decifrar(ticket, chaveServidor);
                String[] partes = conteudo.split("\\|");

                String email         = partes[0];
                SecretKey chaveSessao = CryptoHelper.stringParaChave(partes[1]);
                long timestampTicket  = Long.parseLong(partes[2]);

                // Verifica frescura do ticket (max 1 hora)
                long agora = System.currentTimeMillis();
                if (agora - timestampTicket > 60 * 60 * 1000) {
                    throw new SecurityException("Ticket expirado");
                }

                // Verifica o autenticador (timestamp cifrado)
                String timestampStr = CryptoHelper.decifrar(autenticador, chaveSessao);
                long timestampPedido = Long.parseLong(timestampStr);
                if (Math.abs(agora - timestampPedido) > 5 * 60 * 1000) {
                    throw new SecurityException("Autenticador expirado — possível replay attack");
                }

                // Verifica o MAC da mensagem
                String corpo = envelope.getBody().getTextContent();
                if (!CryptoHelper.verificarMAC(corpo + timestampPedido, mac, chaveSessao)) {
                    throw new SecurityException("MAC inválido — mensagem adulterada!");
                }

                // Guarda a sessão activa
                sessoes.put(email, chaveSessao);
                System.out.println("Pedido autenticado de: " + email);

            } catch (SecurityException e) {
                System.err.println("SEGURANÇA: " + e.getMessage());
                throw new RuntimeException("Acesso negado: " + e.getMessage());
            } catch (Exception e) {
                System.err.println("Erro no handler servidor: " + e.getMessage());
            }
        }
        return true;
    }

    private String getHeaderValue(
            jakarta.xml.soap.SOAPHeader header, String localName) {
        var it = header.getChildElements(
            new QName("http://security.anunciosloc.uan.pt/", localName)
        );
        return it.hasNext() ? ((jakarta.xml.soap.SOAPElement) it.next()).getTextContent() : null;
    }

    @Override
    public boolean handleFault(SOAPMessageContext ctx) { return true; }

    @Override
    public void close(MessageContext ctx) {}

    @Override
    public Set<QName> getHeaders() { return new HashSet<>(); }
}