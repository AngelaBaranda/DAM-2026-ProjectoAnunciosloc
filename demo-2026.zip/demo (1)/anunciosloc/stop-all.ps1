$ErrorActionPreference = "Continue"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$pidsFile = Join-Path $root ".runtime\pids.txt"

if (!(Test-Path $pidsFile)) {
    Write-Host "Nao existe .runtime/pids.txt. Nada para parar."
    exit 0
}

$lines = Get-Content $pidsFile | Where-Object { $_ -and $_.Trim() -ne "" }

foreach ($line in $lines) {
    $parts = $line -split "\|", 4
    if ($parts.Count -lt 2) { continue }

    $pid = $parts[0]
    $name = $parts[1]

    if ($pid -match "^\d+$") {
        try {
            Stop-Process -Id ([int]$pid) -Force -ErrorAction Stop
            Write-Host ("[{0}] parado (PID={1})" -f $name, $pid)
        }
        catch {
            Write-Host ("[{0}] ja nao estava em execucao (PID={1})" -f $name, $pid)
        }
    }
}

Remove-Item $pidsFile -Force -ErrorAction SilentlyContinue
Write-Host "Processos da app terminados."
Write-Host "Se arrancaste Tomcat, para-o com: C:\tomcat9\bin\shutdown.bat"
