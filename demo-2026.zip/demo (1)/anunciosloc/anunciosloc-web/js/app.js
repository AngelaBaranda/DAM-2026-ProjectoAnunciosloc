// URL base do servidor AnunciosLoc
const SERVIDOR = 'http://localhost:8080/anunciosloc';

/** Chaves sessionStorage — sobrevivem a F5 na mesma aba (fecha ao fechar o separador). */
const SESSAO = {
    TOKEN: 'anunciosloc_token',
    EMAIL: 'anunciosloc_email',
    NOME: 'anunciosloc_nome',
    SALDO: 'anunciosloc_saldo'
};

// -------------------------------------------------------
// Navegação entre secções
// -------------------------------------------------------
// Token da sessão actual
let tokenSessao = null;

function guardarSessao(token, email, nome, saldo) {
    sessionStorage.setItem(SESSAO.TOKEN, token);
    sessionStorage.setItem(SESSAO.EMAIL, email);
    sessionStorage.setItem(SESSAO.NOME, nome);
    sessionStorage.setItem(SESSAO.SALDO, String(saldo));
}

function limparSessao() {
    Object.values(SESSAO).forEach((k) => sessionStorage.removeItem(k));
    tokenSessao = null;
}

function mostrarAppPrincipal(email, nome, saldo) {
    document.getElementById('ecrã-auth').style.display = 'none';
    document.getElementById('app-principal').style.display = 'block';
    document.getElementById('user-nome').textContent = nome;
    document.getElementById('user-saldo').textContent = saldo + ' pts';
    document.getElementById('anuncio-email').value = email;
    document.getElementById('receber-email').value = email;
}

async function atualizarResumoDashboard() {
    const resposta = await chamarServidor('obterResumoDashboard', '');
    const v = extrairValor(resposta, 'return');
    if (!v) {
        return;
    }
    const p = v.split('|');
    if (p[0] === 'ERRO') {
        console.warn('obterResumoDashboard:', p[1] || v);
        return;
    }
    if (p.length < 4) {
        return;
    }
    const [u, a, i, e] = p;
    document.getElementById('total-utilizadores').textContent = u;
    document.getElementById('total-anuncios').textContent = a;
    document.getElementById('total-infras').textContent = i;
    document.getElementById('total-entregas').textContent = e;
}

async function atualizarCabecalhoUtilizador() {
    if (!tokenSessao) {
        return;
    }
    const resposta = await chamarServidor('validarSessao', `<arg0>${tokenSessao}</arg0>`);
    const r = extrairValor(resposta, 'return');
    if (!r || !r.startsWith('OK|')) {
        return;
    }
    const partes = r.split('|');
    if (partes.length < 4) {
        return;
    }
    const nome = partes[1];
    const saldo = partes[2];
    const email = partes[3];
    document.getElementById('user-nome').textContent = nome;
    document.getElementById('user-saldo').textContent = saldo + ' pts';
    sessionStorage.setItem(SESSAO.NOME, nome);
    sessionStorage.setItem(SESSAO.SALDO, saldo);
    sessionStorage.setItem(SESSAO.EMAIL, email);
}

// -------------------------------------------------------
// Autenticação
// -------------------------------------------------------
function mostrarTab(tab) {
    document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
    document.getElementById('tab-' + tab).classList.add('active');
    event.target.classList.add('active');
}

async function fazerLogin() {
    const email = document.getElementById('login-email').value.trim();
    const senha = document.getElementById('login-senha').value;
    const erroEl = document.getElementById('login-erro');

    if (!email || !senha) {
        erroEl.textContent = 'Preenche email e senha';
        return;
    }

    const resposta = await chamarServidor('login',
        `<arg0>${email}</arg0><arg1>${senha}</arg1>`
    );
    const resultado = extrairValor(resposta, 'return');

    if (resultado?.startsWith('OK')) {
        const partes = resultado.split('|');
        tokenSessao = partes[1];
        const nome  = partes[2];
        const saldo = partes[3];

        guardarSessao(tokenSessao, email, nome, saldo);
        mostrarAppPrincipal(email, nome, saldo);

        mostrarNotificacao('Bem-vinda, ' + nome + '!', 'sucesso');
        await atualizarResumoDashboard();
        verificarServidor();
    } else {
        erroEl.textContent = resultado?.replace('ERRO: ', '') || 'Erro ao entrar';
    }
}

async function fazerRegisto() {
    const nome  = document.getElementById('reg-nome').value.trim();
    const email = document.getElementById('reg-email').value.trim();
    const senha = document.getElementById('reg-senha').value;
    const erroEl = document.getElementById('registo-erro');

    if (!nome || !email || !senha) {
        erroEl.textContent = 'Preenche todos os campos';
        return;
    }
    if (senha.length < 6) {
        erroEl.textContent = 'A senha deve ter pelo menos 6 caracteres';
        return;
    }

    const resposta = await chamarServidor('registarUtilizador',
        `<arg0>${email}</arg0><arg1>${nome}</arg1><arg2>${senha}</arg2>`
    );
    const resultado = extrairValor(resposta, 'return');

    if (resultado?.startsWith('OK')) {
        erroEl.style.color = '#2ecc71';
        erroEl.textContent = 'Conta criada! Podes fazer login agora.';
        setTimeout(() => mostrarTab('login'), 1500);
    } else {
        erroEl.style.color = '#e74c3c';
        erroEl.textContent = resultado?.replace('ERRO: ', '') || 'Erro ao criar conta';
    }
}

async function fazerLogout() {
    const token = tokenSessao || sessionStorage.getItem(SESSAO.TOKEN);
    if (token) {
        const resposta = await chamarServidor('logout', `<arg0>${token}</arg0>`);
        const resultado = extrairValor(resposta, 'return');
        if (resultado && !resultado.startsWith('OK')) {
            console.warn('logout servidor:', resultado);
        }
    }
    limparSessao();
    document.getElementById('app-principal').style.display = 'none';
    document.getElementById('ecrã-auth').style.display     = 'flex';
    document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
    document.getElementById('tab-login')?.classList.add('active');
    document.querySelector('.auth-tab')?.classList.add('active');
    mostrarNotificacao('Sessão terminada', 'sucesso');
}

function mostrarSecao(id, evt) {
    document.querySelectorAll('.secao').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    document.getElementById(id).classList.add('active');
    const btn = evt && (evt.currentTarget || evt.target);
    if (btn && btn.classList && btn.classList.contains('nav-btn')) {
        btn.classList.add('active');
    }
    if (id === 'dashboard') {
        void atualizarResumoDashboard();
    }
}

// -------------------------------------------------------
// Comunicação com o servidor (via fetch)
// -------------------------------------------------------
async function chamarServidor(operacao, parametros) {
    try {
        // Constrói o envelope SOAP
        const soap = `<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
                  xmlns:srv="http://server.anunciosloc.uan.pt/">
    <soapenv:Body>
        <srv:${operacao}>
            ${parametros}
        </srv:${operacao}>
    </soapenv:Body>
</soapenv:Envelope>`;

        const resposta = await fetch(SERVIDOR, {
            method: 'POST',
            headers: {
                'Content-Type': 'text/xml;charset=UTF-8',
                // JAX-WS Metro publica wsdl com soapAction="" para todas operações.
                SOAPAction: ''
            },
            body: soap
        });

        const texto = await resposta.text();
        return texto;

    } catch (erro) {
        console.error('Erro ao contactar servidor:', erro);
        return null;
    }
}

// Extrai o valor de uma tag XML da resposta SOAP (Metro usa prefixos ns2:, multilinha)
function extrairValor(xml, tag) {
    if (!xml) return null;
    if (/\bfaultcode\b|<\/?S:Fault/i.test(xml)) {
        const mTxt = xml.match(/<faultstring[^>]*>([\s\S]*?)<\/faultstring>/i);
        console.error('SOAP Fault:', mTxt?.[1]?.trim());
        return null;
    }
    const esc = tag.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const re = new RegExp(
        `<[a-zA-Z0-9._-]*:?${esc}\\b[^>]*>([\\s\\S]*?)<\\/[a-zA-Z0-9._-]*:?${esc}\\b[^>]*>`,
        'i'
    );
    const match = xml.match(re);
    return match ? match[1].trim() : null;
}

// -------------------------------------------------------
// Operações do servidor
// -------------------------------------------------------
async function verificarServidor() {
    const dot = document.querySelector('.status-dot');
    const texto = document.getElementById('status-texto');
    texto.textContent = 'A verificar...';

    const resposta = await chamarServidor('ping', '');

    if (resposta) {
        dot.className = 'status-dot online';
        const msg = extrairValor(resposta, 'return');
        texto.textContent = msg || 'Servidor activo';
        if (tokenSessao) {
            void atualizarResumoDashboard();
        }
    } else {
        dot.className = 'status-dot offline';
        texto.textContent = 'Servidor inacessível — verifica se está a correr na porta 8080';
    }
}

async function ativarUtilizador() {
    const email = document.getElementById('email-input').value.trim();
    if (!email) { mostrarNotificacao('Introduz um email válido', 'erro'); return; }

    const resposta = await chamarServidor('ativarUtilizador', `<arg0>${email}</arg0>`);
    const resultado = extrairValor(resposta, 'return');

    if (resultado?.startsWith('OK')) {
        mostrarNotificacao('Utilizador activado: ' + email, 'sucesso');
        document.getElementById('email-input').value = '';
        await atualizarResumoDashboard();
    } else {
        mostrarNotificacao(resultado || 'Erro ao activar utilizador', 'erro');
    }
}

async function consultarSaldo() {
    const email = document.getElementById('email-saldo').value.trim();
    if (!email) { mostrarNotificacao('Introduz um email', 'erro'); return; }

    const resposta = await chamarServidor('consultarSaldo', `<arg0>${email}</arg0>`);
    const saldo = extrairValor(resposta, 'return');
    const div = document.getElementById('resultado-saldo');

    if (saldo && saldo !== '-1') {
        div.className = 'resultado sucesso';
        div.textContent = `💰 Saldo de ${email}: ${saldo} pontos`;
    } else {
        div.className = 'resultado erro';
        div.textContent = 'Utilizador não encontrado ou sem saldo';
    }
}

async function listarInfraestruturas() {
    const lat = document.getElementById('lat-input').value;
    const lon = document.getElementById('lon-input').value;
    const k   = document.getElementById('k-input').value;

    const parametros = `<arg0>${lat}</arg0><arg1>${lon}</arg1><arg2>${k}</arg2>`;
    const resposta = await chamarServidor('listarInfraestruturas', parametros);
    const resultado = extrairValor(resposta, 'return');

    const lista = document.getElementById('lista-infras');
    lista.innerHTML = '';

    if (resultado) {
        const linhas = resultado.split('\n').filter(l => l.trim());
        linhas.forEach((linha, i) => {
            if (i === 0) return; // salta o cabeçalho
            const div = document.createElement('div');
            div.className = 'item-lista';
            div.innerHTML = `
                <div>
                    <div class="nome">📡 ${linha.trim()}</div>
                    <div class="detalhes">Infraestrutura disponível</div>
                </div>
                <span class="badge">Activa</span>
            `;
            lista.appendChild(div);
        });
    } else {
        lista.innerHTML = '<p style="color:#888;text-align:center;padding:20px">Sem infraestruturas encontradas</p>';
    }
}

async function postarAnuncio() {
    const email = document.getElementById('anuncio-email').value.trim();
    const local = document.getElementById('anuncio-local').value.trim();
    const texto = document.getElementById('anuncio-texto').value.trim();

    if (!email || !local || !texto) {
        mostrarNotificacao('Preenche todos os campos', 'erro');
        return;
    }

    const parametros = `<arg0>${email}</arg0><arg1>${local}</arg1><arg2>${texto}</arg2>`;
    const resposta = await chamarServidor('postarMensagem', parametros);
    const resultado = extrairValor(resposta, 'return');

    if (resultado?.startsWith('OK')) {
        mostrarNotificacao('Anúncio publicado com sucesso!', 'sucesso');
        document.getElementById('anuncio-texto').value = '';
        await atualizarResumoDashboard();
        await atualizarCabecalhoUtilizador();
    } else {
        mostrarNotificacao(resultado || 'Erro ao publicar anúncio', 'erro');
    }
}

async function receberAnuncios() {
    const email = document.getElementById('receber-email').value.trim();
    const local = document.getElementById('receber-local').value.trim();
    if (!email || !local) { mostrarNotificacao('Preenche email e local', 'erro'); return; }

    const parametros = `<arg0>${email}</arg0><arg1>${local}</arg1>`;
    const resposta = await chamarServidor('receberMensagem', parametros);
    const resultado = extrairValor(resposta, 'return');
    const div = document.getElementById('resultado-anuncios');

    if (resultado && !resultado.startsWith('ERRO')) {
        div.className = 'resultado info';
        div.innerHTML = resultado.replace(/\n/g, '<br>');
        await atualizarResumoDashboard();
        await atualizarCabecalhoUtilizador();
    } else {
        div.className = 'resultado erro';
        div.textContent = resultado || 'Erro ao receber anúncios';
    }
}

// -------------------------------------------------------
// Notificações
// -------------------------------------------------------
function mostrarNotificacao(mensagem, tipo) {
    const el = document.getElementById('notificacao');
    el.textContent = mensagem;
    el.className = `notificacao ${tipo} visivel`;
    setTimeout(() => {
        el.classList.remove('visivel');
    }, 3000);
}

// -------------------------------------------------------
// Inicialização
// -------------------------------------------------------
window.onload = async function() {
    const ok = await restaurarSessaoAoCarregar();
    if (ok) {
        await atualizarResumoDashboard();
    }
    verificarServidor();
};

async function restaurarSessaoAoCarregar() {
    const t = sessionStorage.getItem(SESSAO.TOKEN);
    if (!t) {
        return false;
    }
    const resposta = await chamarServidor('validarSessao', `<arg0>${t}</arg0>`);
    const resultado = extrairValor(resposta, 'return');
    if (!resultado || !resultado.startsWith('OK|')) {
        limparSessao();
        return false;
    }
    const partes = resultado.split('|');
    if (partes.length < 4) {
        limparSessao();
        return false;
    }
    const nome = partes[1];
    const saldo = partes[2];
    const email = partes[3];
    tokenSessao = t;
    guardarSessao(t, email, nome, saldo);
    mostrarAppPrincipal(email, nome, saldo);
    return true;
}