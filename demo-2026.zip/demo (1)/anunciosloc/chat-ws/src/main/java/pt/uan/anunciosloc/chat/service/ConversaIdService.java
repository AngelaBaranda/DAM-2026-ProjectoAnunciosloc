package pt.uan.anunciosloc.chat.service;

import org.springframework.stereotype.Service;

import java.util.Locale;

@Service
public class ConversaIdService {

    /**
     * Id estável para a conversa entre A e B (independente de quem envia primeiro).
     * Ex.: a@x.com + b@y.com → {@code a@x.com|b@y.com}
     */
    public String idConversa(String emailA, String emailB) {
        if (emailA == null || emailB == null) {
            throw new IllegalArgumentException("Emails obrigatórios");
        }
        String a = emailA.trim().toLowerCase(Locale.ROOT);
        String b = emailB.trim().toLowerCase(Locale.ROOT);
        if (a.compareTo(b) <= 0) {
            return a + "|" + b;
        }
        return b + "|" + a;
    }

    /** Destino STOMP: /topic/conversa/{id} */
    public String topicConversa(String emailA, String emailB) {
        return "/topic/conversa/" + idConversa(emailA, emailB);
    }
}
