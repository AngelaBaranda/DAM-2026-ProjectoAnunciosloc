package pt.uan.anunciosloc.chat.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

/**
 * Configuração STOMP sobre WebSocket.
 * <ul>
 *   <li>Cliente envia para {@code /app/enviar-mensagem}</li>
 *   <li>Servidor retransmite para {@code /topic/conversa/{idConversa}}</li>
 * </ul>
 */
@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    @Override
    public void configureMessageBroker(MessageBrokerRegistry registry) {
        // Broker em memória: subscrições /topic/... e /queue/...
        registry.enableSimpleBroker("/topic", "/queue");
        // Prefixo dos destinos que o cliente usa para ENVIAR ao servidor
        registry.setApplicationDestinationPrefixes("/app");
        registry.setUserDestinationPrefix("/user");
    }

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        // Handshake WebSocket (telefone / browser)
        registry.addEndpoint("/ws-chat")
            .setAllowedOriginPatterns("*");

        // Fallback SockJS (útil em browsers antigos; Android nativo usa WebSocket directo)
        registry.addEndpoint("/ws-chat")
            .setAllowedOriginPatterns("*")
            .withSockJS();
    }
}
