package pt.uan.anunciosloc.chat.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;
import pt.uan.anunciosloc.chat.dto.MensagemChatDto;
import pt.uan.anunciosloc.chat.service.ChatPersistenceService;
import pt.uan.anunciosloc.chat.service.ConversaIdService;

/**
 * Controller STOMP — recebe mensagens dos telemóveis e retransmite em tempo real.
 *
 * <h3>Fluxo</h3>
 * <ol>
 *   <li>Telemóvel A e B ligam a {@code ws://servidor:8086/ws-chat} e subscrevem
 *       {@code /topic/conversa/{idConversa}}</li>
 *   <li>Telemóvel A envia STOMP SEND para {@code /app/enviar-mensagem} com JSON</li>
 *   <li>Este controller valida, grava na BD e publica no topic da conversa</li>
 *   <li>Telemóvel B recebe instantaneamente (se estiver subscrito)</li>
 * </ol>
 *
 * <h3>Exemplo JSON (corpo STOMP)</h3>
 * <pre>
 * {
 *   "remetente": "alice@uan.ao",
 *   "destinatario": "bob@uan.ao",
 *   "texto": "Olá!"
 * }
 * </pre>
 */
@Controller
public class ChatController {

    private static final Logger log = LoggerFactory.getLogger(ChatController.class);

    private final SimpMessagingTemplate messagingTemplate;
    private final ConversaIdService conversaIdService;
    private final ChatPersistenceService persistence;

    public ChatController(
            SimpMessagingTemplate messagingTemplate,
            ConversaIdService conversaIdService,
            ChatPersistenceService persistence) {
        this.messagingTemplate = messagingTemplate;
        this.conversaIdService = conversaIdService;
        this.persistence = persistence;
    }

    /**
     * Endpoint de aplicação STOMP: cliente envia para {@code /app/enviar-mensagem}.
     * O Spring remove o prefixo {@code /app} e mapeia aqui.
     */
    @MessageMapping("/enviar-mensagem")
    public void enviarMensagem(@Payload MensagemChatDto mensagem) {
        if (mensagem == null) {
            return;
        }

        String remetente = trim(mensagem.getRemetente());
        String destinatario = trim(mensagem.getDestinatario());
        String texto = trim(mensagem.getTexto());

        if (remetente.isEmpty() || destinatario.isEmpty() || texto.isEmpty()) {
            log.warn("Mensagem inválida: remetente/destinatario/texto em falta");
            return;
        }
        if (remetente.equalsIgnoreCase(destinatario)) {
            log.warn("Mensagem recusada: remetente = destinatario ({})", remetente);
            return;
        }

        String conversaId = conversaIdService.idConversa(remetente, destinatario);
        String topic = conversaIdService.topicConversa(remetente, destinatario);
        long agora = System.currentTimeMillis();

        MensagemChatDto broadcast = new MensagemChatDto(
            remetente,
            destinatario,
            texto,
            agora,
            conversaId
        );

        try {
            persistence.guardar(remetente, destinatario, texto);
        } catch (Exception e) {
            log.error("Falha ao persistir mensagem: {}", e.getMessage());
        }

        // Retransmite para todos os subscritores do topic desta conversa
        messagingTemplate.convertAndSend(topic, broadcast);

        log.info("Chat {} → {} publicado em {}", remetente, destinatario, topic);
    }

    private static String trim(String s) {
        return s == null ? "" : s.trim();
    }
}
