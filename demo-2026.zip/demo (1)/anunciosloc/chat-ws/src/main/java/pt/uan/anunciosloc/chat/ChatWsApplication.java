package pt.uan.anunciosloc.chat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatWsApplication {

    public static void main(String[] args) {
        SpringApplication.run(ChatWsApplication.class, args);
    }
}
