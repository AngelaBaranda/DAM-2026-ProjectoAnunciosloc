package pt.uan.anunciosloc.chat.config;

import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import pt.uan.anunciosloc.chat.service.ChatPersistenceService;

@Component
public class DatabaseInit {

    private final ChatPersistenceService persistence;

    public DatabaseInit(ChatPersistenceService persistence) {
        this.persistence = persistence;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void onReady() {
        persistence.initSchema();
    }
}
