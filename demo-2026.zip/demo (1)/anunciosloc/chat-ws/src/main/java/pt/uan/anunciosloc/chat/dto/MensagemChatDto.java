package pt.uan.anunciosloc.chat.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Payload JSON trocado entre telemóveis via STOMP.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MensagemChatDto {

    private String remetente;
    private String destinatario;
    private String texto;
    private Long timestamp;
    private String conversaId;

    public MensagemChatDto() {
    }

    public MensagemChatDto(String remetente, String destinatario, String texto, Long timestamp, String conversaId) {
        this.remetente = remetente;
        this.destinatario = destinatario;
        this.texto = texto;
        this.timestamp = timestamp;
        this.conversaId = conversaId;
    }

    public String getRemetente() {
        return remetente;
    }

    public void setRemetente(String remetente) {
        this.remetente = remetente;
    }

    public String getDestinatario() {
        return destinatario;
    }

    public void setDestinatario(String destinatario) {
        this.destinatario = destinatario;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public Long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }

    public String getConversaId() {
        return conversaId;
    }

    public void setConversaId(String conversaId) {
        this.conversaId = conversaId;
    }
}
