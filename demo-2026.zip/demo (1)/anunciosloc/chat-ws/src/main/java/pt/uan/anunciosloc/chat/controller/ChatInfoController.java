package pt.uan.anunciosloc.chat.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class ChatInfoController {

    @GetMapping("/")
    public Map<String, Object> info() {
        return Map.of(
            "servico", "AnunciosLoc Chat WebSocket (STOMP)",
            "porta", 8086,
            "endpoint_ws", "/ws-chat",
            "enviar", "/app/enviar-mensagem",
            "subscrever", "/topic/conversa/{emailA|emailB}",
            "exemplo_topic", "/topic/conversa/alice@uan.ao|bob@uan.ao"
        );
    }
}
