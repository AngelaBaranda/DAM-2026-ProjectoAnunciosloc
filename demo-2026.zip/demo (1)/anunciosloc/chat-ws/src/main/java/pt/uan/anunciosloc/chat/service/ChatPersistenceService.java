package pt.uan.anunciosloc.chat.service;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class ChatPersistenceService {

    private final JdbcTemplate jdbc;

    public ChatPersistenceService(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void initSchema() {
        jdbc.execute(
            "CREATE TABLE IF NOT EXISTS mensagens_chat ("
                + "id BIGSERIAL PRIMARY KEY, "
                + "remetente_email VARCHAR(320) NOT NULL, "
                + "destinatario_email VARCHAR(320) NOT NULL, "
                + "texto TEXT NOT NULL, "
                + "enviada_em TIMESTAMPTZ NOT NULL DEFAULT NOW())"
        );
        jdbc.execute(
            "CREATE INDEX IF NOT EXISTS idx_chat_conversa "
                + "ON mensagens_chat(remetente_email, destinatario_email, enviada_em)"
        );
    }

    public void guardar(String remetente, String destinatario, String texto) {
        jdbc.update(
            "INSERT INTO mensagens_chat(remetente_email, destinatario_email, texto) VALUES (?, ?, ?)",
            remetente.trim(),
            destinatario.trim(),
            texto.trim()
        );
    }
}
