# Testa se o telemovel consegue alcançar os servidores (corre no PC)
$ErrorActionPreference = "Continue"

function Get-LanIpv4 {
    Get-NetIPAddress -AddressFamily IPv4 |
        Where-Object { $_.IPAddress -notlike '127.*' -and $_.PrefixOrigin -ne 'WellKnown' } |
        Select-Object -ExpandProperty IPAddress -First 1
}

$ip = Get-LanIpv4
if (-not $ip) {
    Write-Host "ERRO: Nao foi encontrado IP Wi-Fi. Liga o PC a uma rede."
    exit 1
}

Write-Host ""
Write-Host "=== AnunciosLoc - teste de ligacao mobile ===" -ForegroundColor Cyan
Write-Host "IP do PC na rede: $ip"
Write-Host ""

$checks = @(
    @{ Name = "AnunciosLoc (8080)"; Url = "http://${ip}:8080/anunciosloc?wsdl" },
    @{ Name = "Kerberos (8085)";     Url = "http://${ip}:8085/kerberos?wsdl" }
)

foreach ($c in $checks) {
    try {
        $r = Invoke-WebRequest -Uri $c.Url -UseBasicParsing -TimeoutSec 5
        Write-Host "[OK] $($c.Name) -> $($r.StatusCode)" -ForegroundColor Green
    } catch {
        Write-Host "[FALHA] $($c.Name) -> $($_.Exception.Message)" -ForegroundColor Red
    }
}

Write-Host ""
Write-Host "Portas em escuta:" -ForegroundColor Yellow
netstat -ano | findstr "LISTENING" | findstr ":808"

Write-Host ""
Write-Host "Configura a app Android com estes URLs (mesma Wi-Fi):" -ForegroundColor Cyan
Write-Host "  Kerberos:    http://${ip}:8085/kerberos"
Write-Host "  AnunciosLoc: http://${ip}:8080/anunciosloc"
Write-Host "  Emulador:    http://10.0.2.2:8085/kerberos e http://10.0.2.2:8080/anunciosloc"
Write-Host ""
Write-Host "No browser do TELEMOVEL abre:" -ForegroundColor Cyan
Write-Host "  http://${ip}:8085/kerberos?wsdl"
Write-Host "  (se nao abrir XML = rede/firewall/IP errado na app)"
Write-Host ""
